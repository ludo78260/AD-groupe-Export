@echo off
REM Lance l'exportateur de groupes Active Directory.
REM Au premier lancement, installe la dependance ldap3 si besoin.

setlocal
cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 (
    echo Python est introuvable dans le PATH.
    echo Installez Python 3.9 ou plus recent depuis https://www.python.org/downloads/
    echo puis cochez "Add python.exe to PATH" pendant l'installation.
    pause
    exit /b 1
)

python -c "import ldap3" >nul 2>nul
if errorlevel 1 (
    echo Installation de la dependance ldap3...
    python -m pip install --user ldap3
    if errorlevel 1 (
        echo Echec de l'installation de ldap3.
        pause
        exit /b 1
    )
)

start "" pythonw ad_group_exporter.py
if errorlevel 1 (
    echo pythonw indisponible, lancement avec python...
    python ad_group_exporter.py
)
endlocal
