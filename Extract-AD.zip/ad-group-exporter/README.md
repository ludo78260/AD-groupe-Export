# Exportateur de groupes Active Directory — TOUILLET Ludovic — HNCS-Groupe

**Version livrée : 2026-09-28** — affichée dans la barre d'état de la fenêtre ; si votre exe ne l'affiche pas, c'est qu'il a été construit depuis un fichier plus ancien.

Application Windows (fenêtre Tkinter) qui liste les membres d'un groupe
Active Directory puis les exporte en CSV ouvrable directement dans Excel.

- connexion à un contrôleur de domaine en **LDAPS (636)**, **LDAP + StartTLS (389)** ou LDAP clair ;
- authentification par **session Windows en cours** (SSO Kerberos/NTLM), par **compte NTLM** (`DOMAINE\utilisateur`) ou par **bind simple** ;
- recherche de groupe par nom avec joker `*` ;
- membres **directs** ou **récursifs** (groupes imbriqués dépliés, avec le chemin d'appartenance) ;
- tri, filtrage (comptes actifs / désactivés / utilisateurs uniquement), choix des colonnes ;
- export **CSV** (UTF-8 avec BOM, séparateur `;` par défaut) ou copie dans le presse-papiers ;
- mode **ligne de commande** pour des exports planifiés.

---

## 1. Installation (Windows)

1. Installez Python 3.9 ou plus récent depuis <https://www.python.org/downloads/>
   en cochant **« Add python.exe to PATH »**.
2. Double-cliquez sur **`lancer.bat`** : il installe la seule dépendance
   (`ldap3`) au premier lancement puis ouvre l'application.

Ou à la main :

```bat
python -m pip install ldap3
python app.py
```

> Aucun autre composant n'est nécessaire : Tkinter est fourni avec Python pour
> Windows. Le mot de passe saisi reste en mémoire et n'est **jamais** écrit sur
> le disque ; seuls le serveur, le port, le protocole, la base et le nom de
> compte sont mémorisés dans `%APPDATA%\ADGroupExporter\settings.json`.

---

## 2. Utilisation

### Étape 1 — Connexion

| Champ | Valeur conseillée |
|---|---|
| Contrôleur de domaine | `dc1.corp.local` (ou l'IP du DC). Un nom court est complété avec le domaine DNS saisi. |
| Port | `636` en LDAPS, `389` en StartTLS |
| Protocole | **LDAPS** de préférence ; décochez « Vérifier le certificat » uniquement si le DC utilise un certificat auto-signé |
| Base de recherche | vide = détection automatique : rootDSE (`defaultNamingContext`, racine de la forêt), puis déduction depuis le domaine DNS saisi, le FQDN du serveur ou l'UPN du compte ; bouton « Déduire » pour la calculer sans se connecter ; à remplir à la main (ex. `DC=societe,DC=fr`) seulement si tout échoue |
| Authentification | « Session Windows en cours » si vous êtes sur un poste joint au domaine |

Cliquez sur **Se connecter**. En cas d'échec, le message indique la cause
(hôte injoignable, identifiants refusés, StartTLS refusé…).

### Étape 2 — Groupe

Saisissez tout ou partie du nom (`compta`, `GRP_*`…), cliquez sur
**Rechercher le groupe**, puis choisissez le groupe dans la liste.
Cochez **Inclure les groupes imbriqués** pour dépliquer les groupes contenus
dans le groupe.

### Étape 3 — Résultats et export

- **Lister les membres (F5)** remplit le tableau ;
- cliquez sur un en-tête de colonne pour **trier** ;
- double-clic sur une ligne : **tous les attributs** de l'objet ;
- le filtre « Afficher » limite l'affichage **et** l'export ;
- **Exporter en CSV… (Ctrl+E)** écrit le fichier, **Copier dans le presse-papiers**
  permet de coller directement dans Excel ;
- **Colonnes…** choisit les colonnes affichées et exportées.

Colonnes disponibles : compte, nom affiché, UPN, e-mail, fonction, service,
société, responsable, téléphone, état, type d'objet, appartenance
(`Direct` / `Via <groupe>`), chemin des groupes imbriqués, dernière connexion,
date de création, distinguishedName.

### Notes sur les données

- **État** est décodé depuis `userAccountControl` : `Actif`, `Désactivé`,
  `Verrouillé`, `Mot de passe expiré`, `Actif (MDP à définir)`.
- **Dernière connexion** utilise `lastLogonTimestamp` (répliqué, précis à ~14
  jours) ; `Jamais` si la valeur est à 0.
- Les **dates** `whenCreated` sont stockées en UTC par AD et affichées dans le
  fuseau du poste.
- Les **groupes**, **ordinateurs**, **contacts** et **principaux externes**
  (membres d'autres domaines) sont également listés, avec leur type.
- Les groupes de plus de 1 500 membres sont gérés (attributs `member;range=…`).

---

## 3. Mode ligne de commande

Utile pour un export planifié :

```bat
python app.py --cli --server dc1.corp.local --group "GRP_Comptabilité" --recursive --out membres_compta.csv
```

Options : `--port`, `--mode {ldap,ldaps,starttls}`, `--insecure`,
`--base-dn`, `--domain`, `--user`, `--password`, `--auth {sso,ntlm,simple}`,
`--scope {all,enabled,disabled,users}`, `--delimiter`.

Exemple avec compte de service :

```bat
python app.py --cli --server dc1.corp.local --group GRP_Compta --recursive ^
  --user "CORP\svc_lecture" --password "..." --scope enabled --out actifs.csv
```

---

## 4. Dépannage

| Symptôme | Cause probable / solution |
|---|---|
| « Impossible de joindre … » | Nom du DC erroné, port bloqué par le pare-feu, ou LDAPS non publié. Testez `Test-NetConnection dc1 -Port 636`. |
| « Échec du démarrage StartTLS » | Le DC n'accepte pas StartTLS sur 389, ou certificat invalide. Passez en LDAPS. |
| « Authentification refusée » | Format attendu `DOMAINE\utilisateur` en NTLM. En SSO, lancez l'app avec la session du domaine. |
| Certificat rejeté en LDAPS | Le certificat du DC n'est pas émis par une AC de confiance du poste : installez l'AC racine, ou décochez temporairement « Vérifier le certificat ». |
| Aucun groupe trouvé | La recherche compare désormais le motif au nom complet, au nom « pre-Windows 2000 » (sAMAccountName) et au CN ; essayez un morceau avec `*`. Sinon : base de recherche trop restrictive (laissez-la vide ou mettez `DC=corp,DC=local`), groupe dans un autre domaine de la forêt (port GC 3268), ou droits de lecture insuffisants du compte sur l'OU. |
| Membres « attributs non accessibles » | Droits de lecture insuffisants sur l'OU concernée, ou objet supprimé. |
| `No module named 'Crypto'` puis `unsupported hash type MD4` lors de la connexion NTLM | Les Python récents (OpenSSL 3) n'ont plus MD4, nécessaire à NTLM. Depuis cette version : l'exe embarque `pycryptodome` (construit avec `--collect-submodules Crypto`) **et** le moteur contient un MD4 de secours pur Python — reconstruisez l'exe avec le `creer_exe.bat` à jour, ou remplacez vos fichiers sources par les versions actuelles. |

---

## 5. Construire l'exécutable (.exe)

Trois moyens, du plus simple au plus automatisé :

1. **Sur Windows** : double-cliquez sur **`construire_exe.bat`** — il installe
   PyInstaller si besoin puis produit `dist\ADGroupExporter.exe`
   (fichier unique, ~13 Mo, avec icône).
2. **À la main** : `python build_exe.py` (options : `--console`, `--onedir`,
   `--bundle-tests`, `--nom`).
3. **Depuis Linux** : `bash tools/build_with_wine.sh` — pipeline entièrement
   automatisé et idempotent : installe Wine (+ couche 32 bits), y installe un
   vrai Python Windows 3.12, PyInstaller et ldap3, puis exécute `build_exe.py`
   avec cet interpréteur. C'est ainsi que les exécutables fournis dans
   `exe_windows/` ont été construits **et testés** :
   - `ADGroupExporter.exe` — l'application (sans console) ;
   - `ADGroupExporter_debug.exe` — build console embarquant les tests :
     `ADGroupExporter_debug.exe --selftest` exécute la suite complète
     (63 tests) à l'intérieur même de l'exécutable.

Un exécutable pré-construit est fourni dans `exe_windows/` ; reconstruisez-le
à chaque modification du code avec l'une des commandes ci-dessus.

### Variante autonome : deux fichiers seulement

Si vous ne pouvez récupérer que du texte (pas le dossier complet ni l'.exe),
l'application existe en **fichier unique** :

1. copiez **`ad_group_exporter.py`** et **`creer_exe.bat`** dans un même
   dossier de votre poste ;
2. double-cliquez sur **`creer_exe.bat`**.

Le .bat fait tout, sans rien d'autre à installer :
- détecte Python 3.9+ (`python`, `py -3`, installations classiques) ;
- sinon télécharge et installe Python 3.12 silencieusement ;
- installe `pyinstaller` et `ldap3` ;
- régénère l'icône (intégrée au .bat) ;
- compile `ADGroupExporter.exe` (fichier unique, ~13 Mo) et ouvre
   l'explorateur dessus.

Ce .bat a été validé tel quel sous `cmd.exe` (environnement Wine) : il
produit bien l'exécutable, qui a ensuite été testé (export CSV récursif
contre l'annuaire de test).

---

## 6. Développement et tests

```bash
python run_all.py            # toutes les vérifications
python run_all.py --quick    # tests unitaires seuls
```

Trois niveaux de vérification :

1. **`tests/test_core.py`** — 38 tests unitaires du moteur, sans serveur :
   échappement des filtres LDAP, lecture des DN, conversion des dates
   FILETIME/generalizedTime, décodage du SID et de `userAccountControl`,
   filtres de périmètre, écriture CSV, persistance des réglages.
2. **`tests/test_fake_ad.py`** — 22 tests d'intégration exécutés contre un
   vrai serveur LDAP (OpenLDAP) habillé en Active Directory
   (`tools/ad.schema`, `tools/fake_ad.ldif`) : recherche de groupes, membres
   directs et récursifs, cycles entre groupes, groupe vide, principal externe,
   ordinateur, contact, compte désactivé, erreurs de connexion.
   Nécessite `sudo apt-get install -y slapd ldap-utils`.
3. **`tools/gui_smoke.py`** — test de bout en bout de la fenêtre Tk pilotée
   par script (connexion, recherche, listing, filtres, tri, copie, export CSV,
   choix des colonnes, détail d'une ligne). Nécessite `xvfb-run` sous Linux.

```bash
python tools/run_fake_ad.py --keep          # laisse l'annuaire de test actif sur le port 13389
python tools/with_fake_ad.py --script tools/gui_smoke.py --xvfb
python app.py --selftest                    # tests unitaires + création de la fenêtre
```

### Fichiers

| Fichier | Rôle |
|---|---|
| `app.py` | Interface graphique + mode CLI |
| `ad_core.py` | Moteur LDAP/AD (aucune dépendance à Tkinter) |
| `tests/test_core.py` | Tests unitaires |
| `tests/test_fake_ad.py` | Tests d'intégration |
| `tools/ad.schema`, `tools/fake_ad.ldif` | Annuaire de test « façon AD » |
| `tools/run_fake_ad.py`, `tools/with_fake_ad.py` | Pilotage de l'annuaire de test |
| `tools/gui_smoke.py` | Test automatique de l'interface |
| `lancer.bat` | Lanceur Windows |
| `construire_exe.bat` | Build de l'.exe en un double-clic (Windows) |
| `build_exe.py` | Script de build PyInstaller (Windows / Wine / Linux) |
| `tools/build_with_wine.sh` | Build automatisé de l'.exe depuis Linux (Wine) |
| `exe_windows/` | Exécutables pré-construits et testés sous Wine |

---

## 7. Limites connues

- Lecture seule : l'application ne modifie jamais l'annuaire.
- L'export est au format CSV uniquement (pas d'`.xlsx` ni de `.json`).
- La résolution des membres passe par une indexation de l'annuaire en une passe
  paginée ; au-delà de 50 000 objets, les objets manquants sont relus un par un
  (seuil réglable via le paramètre `scan_cap` de `AdClient`).
- Sous Windows, l'authentification « Session Windows en cours » s'appuie sur
  SSPI (Kerberos) ; si elle échoue et qu'un compte est saisi, l'application
  retente automatiquement en NTLM.
- L'exécutable fourni a été construit puis vérifié sous Wine (fenêtre, connexion
  à un annuaire de test, listing récursif, suite de 63 tests intégrée au build
  debug). Sur un vrai poste Windows, le même `construire_exe.bat` reproduit le
  build nativement.
