@echo off
setlocal
cd /d "%~dp0"

echo Source utilise : ad_group_exporter.py
echo L'application doit afficher la version 2026-09-28 dans la barre d'etat.
title Creation de ADGroupExporter.exe

echo ============================================================
echo  Creation automatique de l'exe ADGroupExporter
echo ============================================================

if not exist ad_group_exporter.py (
    echo ERREUR : le fichier ad_group_exporter.py est absent a cote de ce .bat.
    echo Copiez ces deux fichiers dans le meme dossier, puis relancez.
    pause
    exit /b 1
)

echo.
echo [1/4] Recherche de Python 3.9 ou plus recent...
set "PYTHON="
set "PYARGS="
if defined AD_PYTHON (
    set "PYTHON=%AD_PYTHON%"
) else (
    where python >nul 2>nul && python -c "import sys; raise SystemExit(0 if sys.version_info[0] * 10 + sys.version_info[1] >= 39 else 1)" >nul 2>nul && set "PYTHON=python"
    if not defined PYTHON (
        where py >nul 2>nul && py -3 -c "import sys; raise SystemExit(0 if sys.version_info[0] * 10 + sys.version_info[1] >= 39 else 1)" >nul 2>nul && set "PYTHON=py" && set "PYARGS=-3"
    )
    for %%V in (313 312 311 310 39) do (
        if not defined PYTHON if exist "%LocalAppData%\Programs\Python\Python%%V\python.exe" set "PYTHON=%LocalAppData%\Programs\Python\Python%%V\python.exe"
    )
)

if not defined PYTHON (
    echo Python introuvable : telechargement et installation silencieuse de Python 3.12...
    set "INST=%TEMP%\python-3.12.9-amd64.exe"
    if not exist "%INST%" (
        where curl >nul 2>nul && curl -fsSL -o "%INST%" https://www.python.org/ftp/python/3.12.9/python-3.12.9-amd64.exe
    )
    if not exist "%INST%" (
        powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.9/python-3.12.9-amd64.exe' -OutFile '%INST%'"
    )
    if not exist "%INST%" (
        echo ERREUR : telechargement de Python impossible [verifiez le reseau].
        pause
        exit /b 1
    )
    "%INST%" /quiet InstallAllUsers=0 PrependPath=1 Include_test=0 Include_launcher=0
    if exist "%LocalAppData%\Programs\Python\Python312\python.exe" set "PYTHON=%LocalAppData%\Programs\Python\Python312\python.exe"
)
if not defined PYTHON (
    echo ERREUR : Python n'a pas pu etre installe automatiquement.
    echo Installez-le manuellement depuis https://www.python.org/downloads/
    echo en cochant "Add python.exe to PATH", puis relancez ce script.
    pause
    exit /b 1
)
echo      Python utilise : %PYTHON% %PYARGS%

echo.
echo [2/4] Dependances PyInstaller + ldap3 (+ pycryptodome pour NTLM)...
"%PYTHON%" %PYARGS% -c "import PyInstaller, ldap3" >nul 2>nul
if errorlevel 1 (
    "%PYTHON%" %PYARGS% -m pip install --user --quiet pyinstaller ldap3 pycryptodome
    if errorlevel 1 (
        "%PYTHON%" %PYARGS% -m pip install --quiet pyinstaller ldap3 pycryptodome
    )
)
"%PYTHON%" %PYARGS% -c "import PyInstaller, ldap3" >nul 2>nul
if errorlevel 1 (
    echo ERREUR : installation de PyInstaller/ldap3 impossible [verifiez le reseau].
    pause
    exit /b 1
)
set "CRYPTO_FLAG="
"%PYTHON%" %PYARGS% -c "import Crypto" >nul 2>nul
if errorlevel 1 (
    "%PYTHON%" %PYARGS% -m pip install --user --quiet pycryptodome >nul 2>nul
)
"%PYTHON%" %PYARGS% -c "import Crypto" >nul 2>nul
if errorlevel 1 (
    echo      pycryptodome indisponible : l'exe utilisera le MD4 de secours integre.
) else (
    set "CRYPTO_FLAG=--collect-submodules Crypto"
)

echo.
echo [3/4] Preparation de l'icone...
if exist "%TMP%\adexe_icon.b64" del "%TMP%\adexe_icon.b64"
echo AAABAAUAEBAAAAAAIAD2AgAAVgAAABgYAAAAACAAvQQAAEwDAAAgIAAAAAAgAAUGAAAJCAAAMDAAAAAAIACeCAAADg4AAEBA>> "%TMP%\adexe_icon.b64"
echo AAAAACAA6AEAAKwWAACJUE5HDQoaCgAAAA1JSERSAAAAEAAAABAIBgAAAB/z/2EAAAK9SURBVHicbZNNaNxlEMZ/837sP/vR>> "%TMP%\adexe_icon.b64"
echo TZPGim1PkqqghyIU/ELRgxdFhHQlJehNekkv9igitgevYvbirSctSSxoQS+CB/UiWIVgUVgopRCSYJvsNpvt7v99ZzystkQ7>> "%TMP%\adexe_icon.b64"
echo x2d4hmeeZ0ZoLXtW3srNVnvWu+opLE2aZuEBJc4bErpZB6u9lcUOrWUvAFNz7dPE6hLiDoEBD+Rzr2d6i3JwdvvLxS+k2WrP>> "%TMP%\adexe_icon.b64"
echo ioXfXAh1K4fJe5F/R+RsAHgv/1CFrGqEIlhKfZN0Ijhz8xKLuo32kjgXuv0RIpDVOFCt4JywD6tVkDRMLtbqVuq8Q6wJmPMi>> "%TMP%\adexe_icon.b64"
echo /cGIhZef4LuP5zj/9rMYRv/uiIVX7mM5KxgCGGLNILjsBOkPSp4+/jAXz70KwItPHeXGVo+ffl/n4nv3sa2dPdpf/cr0RF0y>> "%TMP%\adexe_icon.b64"
echo LgczExEhm+GdMEoZVSMGj3cOBcqkZFVi8FSCR9UQATMTB2A2NujwZI0yKcE7vBNmmhM8duQgakbwDgEa1UhRBLKODQ4heHaH>> "%TMP%\adexe_icon.b64"
echo JSdmH+LyB6/vC+3CO8/9L8gPF55h+86QpW//4HDDE1SV6AO3e3d546OvcQK7g5LnnzzK+/Mnid6z/MOffPbNGs1ahaTG5naf>> "%TMP%\adexe_icon.b64"
echo WhEZpRHBTC1Gx8btXa5v9jCD4B2fnHlpvK8Zr518lPOf/8z3V28Qi4h3Qq1xACvVgoHHsBgdRRFQNRrVCjPN6j3Z1SJwbKbB>> "%TMP%\adexe_icon.b64"
echo 9Y0ujWokZcUMM/AOkx4gppgqqMHNjS4/XlsnZSVno7O+w9XOFmpGVsPUxodp0nMqeknLYV9iETBNqcz5yoU386kXjufgXY7B>> "%TMP%\adexe_icon.b64"
echo 5cePTeVfPj2dj0zX86jMyVWKoOWwr6KXQm9lsTM1134X4pL66qHJeuDa+h5rl9fAQGSsqloJTE8dZHPXAHfLWTq7vbrYkf++>> "%TMP%\adexe_icon.b64"
echo c9I0eefmX4Jz+/NLifjItDVrE91yd2e1d+Vch9ay/xslYGIjffAHCwAAAABJRU5ErkJggolQTkcNChoKAAAADUlIRFIAAAAY>> "%TMP%\adexe_icon.b64"
echo AAAAGAgGAAAA4Hc9+AAABIRJREFUeJydll2IVVUUx39r73OO595xvI7TpJOfqeSYDZVhmAqTiROkRhZjZPTiiwVhWUFEkkaP>> "%TMP%\adexe_icon.b64"
echo 4QcFhRBR1EtaZiARmYGZSA9ioGVqgkY2+dl83q9z9l493OuduepAtmC/nMP+r7X+a63/2kLFBFAAujZnxpBdBCk3ZwF95H9k>> "%TMP%\adexe_icon.b64"
echo 58uF4ZgCKmzcJHTfZnM9Zp0x5jm8m4HIzeGrgrGnvffv947179D6l+PNTSp07bAAOX9pn4kbO0gKqEv9TYZfCdkGhjCDL/bv>> "%TMP%\adexe_icon.b64"
echo 7zW3LAEw7Fzlcv7iehM3dmixL1GXKIL5P0ddolrsS0zc2JHzF9ezc5WT1uXbs/nY/W5seKumiSAYABEwIogIqorzWhetMYKp>> "%TMP%\adexe_icon.b64"
echo 0ui94rX6X/EShOpdciFbtDODwUx5oZV4vKYJQ+CC856efAlVECPkshEiVaqNMFBIKCcpIMSRJRuHeK8gGE0Tb2w4fjBTXBhU>> "%TMP%\adexe_icon.b64"
echo 620AfxU8dY4osLzaNY/2ac0c+q2bj/b+ijWCtYaBQplFcyaypnMOhVLK9q+PcvTMJRoyVSdXMRWCG3WD98oXG1bQ0T4RgNWL>> "%TMP%\adexe_icon.b64"
echo 23igrZU12/ZC2bHs/uns2rC8duWpB2fR+fouDp+6UHHihug0w7GtFXrzZVbMn0FH+0TKiSN1niT1rF7cxvy2VkqJY9PT8wEo>> "%TMP%\adexe_icon.b64"
echo pY5S4miIQ157ch6J8/WAXJOBIHivTGjK1rgOrKkVuLkxQxRamhtjFAitQbVSl5ZcljAw6DUO6hx6VUaFlh0/nGSgmGCr4NYI>> "%TMP%\adexe_icon.b64"
echo Z873sffIWco9eT47cBKpdo+qIgKffn+cUn8Ja+pzqGUgIiSpZ0xDxAuP3cuo0NQK5rzSksuw9pF2jp25zNJ7ptS1rfOelQtm>> "%TMP%\adexe_icon.b64"
echo 8tOJvzl25jKZKKhlImO63l1qTfytUed7B4rmw5c6eWbJ7Otq/1+sv1Cm/dlPuNJf8uGoyKSu2FnLwDnP6GzE7RNynPjzH4wR>> "%TMP%\adexe_icon.b64"
echo RMCKIV9KGNcYM35sFgRKiePUuR5GZ0K8KkIl+ygwzJ7czHc//0EUj6qn6Kote2N3TedEhFLiaG1q4KuNjzKhKVub2G1fHuHj>> "%TMP%\adexe_icon.b64"
echo fb+Qa4jxviJdSqVRRsdD83BtV1UjrxxjBOc87z3/EHdNa8Z7xYghEwVsX7eEOVObKZVTbPVORVquwRuJT6lSMamlkcV3T0ZV>> "%TMP%\adexe_icon.b64"
echo McYgAknqCQND59yp5Isp1o4IM7IDgMAY+vIlzl7oq4kegDWVME939xIGQ902sgPlOv33CnFkuXRxgM2fH65+q6iqMcL+o+fY>> "%TMP%\adexe_icon.b64"
echo feAUjQ3RkJIOtyqmaShEB71PzksQ6nBHoRXOXxnk4QUzWP/4XJLUA5UsktRz55RxvL22gyt9RerG96pc++R8QyE6aLr3rM2j>> "%TMP%\adexe_icon.b64"
echo uoUgtqAOVTVG6M+XWT5/Ot+8tZJZk5oIA0NgK9IRBoaWXIZXnriPD15cSqGUVnaDqoI6gtiiuqV7z9p8QNcO2wtbc8VLy008>> "%TMP%\adexe_icon.b64"
echo poOkgOB9mnrumNTEoePdlJKUMLD1FFZ5bx2XJY4CvFfEhoYwE1ZWZstWunbYGy599W6GMUKh5EicQ0S4TsVqjCijMxEy4tKv>> "%TMP%\adexe_icon.b64"
echo 2A2fLbENsMH1K6PO0pRBlzLSs+VfvYMnaMYxp6sAAAAASUVORK5CYIKJUE5HDQoaCgAAAA1JSERSAAAAIAAAACAIBgAAAHN6>> "%TMP%\adexe_icon.b64"
echo evQAAAXMSURBVHictZddiF3VFcd/a5+Pe+7MncnciZFEqiWSB1Mfao2pViIEP+JHW6pTZhDbUJtCnowRbYMizUsRSmmh1j6I>> "%TMP%\adexe_icon.b64"
echo T1LIQydQKalCalunVK1Rgh8FlZpG1IYkYu5M5s6999xzzt6rD2fuzZ07Z+5MlC7YnK//3mvt9fE/awu9MjntcXjKdh6re6fX>> "%TMP%\adexe_icon.b64"
echo ycenlfV8PjkHesUmmX1m6vxKOmTZh217g+qV2x5xam8SL7yBLFHAfE4THH4oapPXjHj/mD15/FccfybtNUJ6lY/e8+vbTGn0>> "%TMP%\adexe_icon.b64"
echo gAmiWzVtoTYFkYEaVhVVxAuQoIxL47+49vwv5p976MWOTuncVCd/u0O9aEYwnqbNFMQgYkC/mAEIqDpQJ8FQoDgrNt45e/iB>> "%TMP%\adexe_icon.b64"
echo l5mc9oTJaW88bA/bpP688aMdmrQSRMIvqLVYVBMJy6HL4pe9cOSbtaTUMByesrZZ32Oi6g5t/x+VA4iE2m4lJqrusM36Hg5P>> "%TMP%\adexe_icon.b64"
echo WcO+J0tiuF3TlkPwiueB7xl8z+CZlXNiTTjB07TlxHA7+54s+dUzUaRkO3GJQZYH3BghSS2zzRhU8UOfkXIIKKoXj0MwuERA>> "%TMP%\adexe_icon.b64"
echo d1bPRJEvYawaBw2QqGhH9WbCly6p8OPvbqMUeLzx77P86dhJSqGP7xlUdc24XitAGhLG6nc2ULTzhWbCPTdu4el9t1CtlLrf>> "%TMP%\adexe_icon.b64"
echo XnjjQ37wy6Ok1uH7hnpjdZwxstQTizoLCUYEktRy2foKzz6yi2qlRJo5MpuPu7Zv5ieT11FvJDirq+MW2hhTzGWFbz1jaDTb>> "%TMP%\adexe_icon.b64"
echo 3H/bV4gCjzRzBH6eXEYMzil7dl3N5ZeOMjfX4oe7rh6I23TJCEmSFXKav/xVLuqU8ZEIEUHkgu9EQESoViKCwEOtWx3ne7gV>> "%TMP%\adexe_icon.b64"
echo +KzQA06Vcjlk5p3/0k7tkvi5xZuX3v6EuXqLymi0Km6+ERMGpj8HVjZAgFZi+dvbn5BkFtPju042v/b+aT47NUecWf761scD>> "%TMP%\adexe_icon.b64"
echo cbVTswiythAYEVrtjDuv+zIHJrczXApwqt3FvcVkenjiWpyDN0+c5aGJawfifM/wmz++xUKc4BuzhGyWGCAISWZZP1pm+vFv>> "%TMP%\adexe_icon.b64"
echo UYkCksxhBFwfRw2VAg5+7/rus3Oajx6cAoFneHRqO9YpB599hfGxMlkvgfUu6nnCwkKb/XdfQyUKAAgXs7p/AFiXs5x1ijGy>> "%TMP%\adexe_icon.b64"
echo DBN4hsDP2f3xe7/OZRtGiRNLbySWeMCpEkU+f//XKdLM4VS7nK6ak1OcZAyVAh78zjV5drscc+z9Mzz3ygesHxvCWkeeSdq9>> "%TMP%\adexe_icon.b64"
echo ptaRWkv/L2KpAU4pRyFHj3/EkVdP9CxCXldOwQiHHr0zp1eXx9ypsnnjKK9/cJaX/vkfGApZXnfCupFSXikrGZDvVKmUA8xQ>> "%TMP%\adexe_icon.b64"
echo 2DMVPM9QO9/k5z+6ift2XoV1rptoqHDp2BB/fmKCrXt/x7n5FoFvltmQWUd/g1PMA067dJpZR+YcjVbChrFhdt+yFecUIxem>> "%TMP%\adexe_icon.b64"
echo iuSLe0b4/s1XMVdv4ZSla1hXpGrtzaZTCHyPdcO5G4tFqFZK6Eq0N8CAYvN6JPANtfkmb574dNGgPldKTjSvvneaIPT7fr+F>> "%TMP%\adexe_icon.b64"
echo 4gCMJpGADg9qPlVzAxpxyv6nZ2ineSl1dHTK8Mixk/z+xXcZG4mwA72ggA5rEomZ3RjHIDOY0KHFnjBGaLZTxkYi7tq+GVVd>> "%TMP%\adexe_icon.b64"
echo EgZhsYJCnztuuJJz51tdrijQ7TChA5mZ3RjHhqf2t9VxVIKyQbH9eBFIUwsODh24g5/edz2h73V33+EHBG792hW88MQEd9+4>> "%TMP%\adexe_icon.b64"
echo hc/mmnheQa4oVoKyUcdRntrfHtiWi+QK1Cl/OPhtbv7q5XkFDGhMOzLxsyM8//qHjAyFF8JR2JYDtUO75w3uMVVnJSiHqEtR>> "%TMP%\adexe_icon.b64"
echo tYBmmdWxSkm3bdmg5xttXYhTrbeS5aOZX2v1li60Ev3G1k2atFMVEUXVoi6VoByqOmtwj9UO7Z7vhG/Vo5kA5ZLf02qv5AHt>> "%TMP%\adexe_icon.b64"
echo XuLUkmY58Qw+mnVklcNp5uxFHdKMCJ4xDm8th9N+IxblwvF8nPGLUA5QAzhXW/V4/j+QuHBxCh38tgAAAABJRU5ErkJggolQ>> "%TMP%\adexe_icon.b64"
echo TkcNChoKAAAADUlIRFIAAAAwAAAAMAgGAAAAVwL5hwAACGVJREFUeJzVmmuMXGUZx3/Pey4zuzs729m2GreUy3IJkEJrG5CK>> "%TMP%\adexe_icon.b64"
echo pIi1lYK0XJYPELwkxC4l1hKVkHiZLlHDBxPbGrAS8YOKJiyREiOxCJYa/UARECXcIlUKVFa6O937zLm8jx/Ozpa2OzNnZ1uF>> "%TMP%\adexe_icon.b64"
echo f/J+mXn/73n+5zzneZ73eQ/UQ7FoKO5x6845mSjucSkWTb0pMjNxitTXZwE61v9gnuQ6N1MZtYjUXXDOULVk2o2ODe0YfvSO>> "%TMP%\adexe_icon.b64"
echo wzPZ814cL6DnIYf+G2OAfM/OXtdvu9mWR+aZtvlLsOGMlBMLBeNhxwdfNNn84SgYf3Ckv3fnsbbNLKCohj6xuXX3nOflF6xC>> "%TMP%\adexe_icon.b64"
echo nB+Bgo3RKAiS+aInWYAAKq7vY5zkkhrfFo4c2jv22F0vV208XsCqosvevii/YcfFTjb3uDhuhy2PWkBBBOHkus5xOrCgCojJ>> "%TMP%\adexe_icon.b64"
echo thuNo+G4PLZmZNfmfVVbjwgoquGlrW7edC12jL8PGxY0CiLEeP9To2tBbSiu72K8UmyDi0fswTc5f2tEn9gjd7W/LzBxtBbj>> "%TMP%\adexe_icon.b64"
echo dL6vjAcQ42kURBin08TRWvr7gum/oGhgqxZu2PklvOxODSZiRJz/p701oRqL3+oQlntLD/feD1vFsKLLAVFr403AcWHqfQib>> "%TMP%\adexe_icon.b64"
echo 2CrKii7HpbtgC93bTlX8CBsDcrLj5Bwggo0Rx48KPdtOLVF42yRxNXObackv17ASzSbaOEamhzGz090UVzAaViLTkl8Omdvo>> "%TMP%\adexe_icon.b64"
echo vzF2AVR1XGyoaW++YwQjwtBYOQl0gOcY5uUyBFE8/duJ5iYiBGyoqjoOkNQ5oiaN66iC6xpGJwKCSsiai87ATNGGRsvse+EA>> "%TMP%\adexe_icon.b64"
echo HfPbcYxgj7FkLtwZVYiaIwJSwnOFwdIEl3/0VK66+Ay+et3y6f9KY2W2PfI8P//DK7x1aJT2Fv8oQ+bCrYfUAowI5SDm0iWL>> "%TMP%\adexe_icon.b64"
echo +PU3r2ZeLkMY2ennVshl6btlJT2Xnc2abzxCOYxPCLehXWknxlYJIsvu71075a8WzzW4TjJUYTKIWHL6An5x52coDQzjew6q>> "%TMP%\adexe_icon.b64"
echo zXNPmABjhMlKyKarLyTjOcRW8d2jqSKQ8Ryi2HLuKQVWf/wsxsYr+J5pmuukiE7pBIgQBBEb112AY2pTjAiq0DU/x7WXns3E>> "%TMP%\adexe_icon.b64"
echo WAXPNU1z04TX1C4kIgyUJlLNtVYZGi0jTmJUs9w0SC1AVVmQb0m3qBE62jKoTVJLs9xU89NMiq3S2uJzx/1/JIji6fh9LKwq>> "%TMP%\adexe_icon.b64"
echo riO8dGCQ7bueo6OjlXIQN82N4sYi0j0BVVqyHr9/7g3i2NZMeVV3+c/hCV5/9R1ybRmsbZ6rKXJBQwEiEMaWwXeG2bx+GZ7r>> "%TMP%\adexe_icon.b64"
echo 1EwyRoTYKmd3Fbhs5Zm8/eYQVrVJ7mBD46FBIjMilMOIS879CFtvvoTLliwCqFmviCRbvEULcvymbwN7//YmP/7d37mr56JZ>> "%TMP%\adexe_icon.b64"
echo ctfzzKvvcOuOJxkerzQvILZKFCuPfvuz5Fp8VBURqVs1JeFQ6WjzuWblmVz1sW4cI7PkZli9/DQe2LKa1V/5FR9aVCCokZ1r>> "%TMP%\adexe_icon.b64"
echo ulCS/iN6111AxnOohDF2Kqs2GjJliLWKYxLXQASlMd8qBJGlHMScs6jAFSuTpFYrJ9QU4BihUg752vUr8FyHjOccVcPXG5C8>> "%TMP%\adexe_icon.b64"
echo kNWLOkYQEhdJw/ddQ9Z3WLywnZs+eS4To2XcGnmhpgtZVVzP4bFn/snS7oVYC3USaVIuO4bSWIVPLVt8VBmQRJikbH7mtQHm>> "%TMP%\adexe_icon.b64"
echo 51sIo7iuO0Vx8vSe/ccAbsbD1sgLNQXEVmlvy7Dp3j3YuPFWWYxBh8a46boVXLH0FKwyHfMVxVoYmQjYsvMpXnn535iOllTr>> "%TMP%\adexe_icon.b64"
echo ZjIu7e3Zmjmh7kusqhRyGaTBXsd1hPJEyOe/8Am29a5K3oP39MyMCBbl9A/n+csPb+Kqb+3ihX8dwncNjRKutVp3b9AwDySR>> "%TMP%\adexe_icon.b64"
echo yNYcqspAaYKzFneyrXcVYWQx5vhoYyTZabVlPR77zgYmKhGVsPa61dFoYzPndmFslVyLz5evWZYsaKRm+7earDKew6arL2Sy>> "%TMP%\adexe_icon.b64"
echo Es66GXDcmnNiA5FV2lt9Prf6PIBUNbxjDBvXXUAQRDVro7SYswAB4lgbZsxjMVCaaPhupcEJ6Tg71RI45Ua8Wl6nnV8Pcxbg>> "%TMP%\adexe_icon.b64"
echo OYZDI5Pc+dM/ISLEtn5oTF5wYfPOp2ht8RvOb4REgIqtXWbVR+IFyhPPvcHBwfFkuRorqSYu98L+d9n32gCe6zR5VdXE5ikB>> "%TMP%\adexe_icon.b64"
echo ItKG8aSZ1VShoy3D80/vZ/ujz+MYQxjNfFejqbt9y/d3MzY4hu+a2XdiVcF4IiJtAELPQ06Bg4uU1kfEmGUaBaTpj1ZLh/Fy>> "%TMP%\adexe_icon.b64"
echo SGd7lge/vpZzTumka37bdOkwE0dRXn2rxJ9fOsjG7U8wL5cFSNfIUqy4PmrtX4WJa0t0vW3YXzKl/i0HNA7c5Ewq3WNwXaFc>> "%TMP%\adexe_icon.b64"
echo CWlv8fjt3eu5fOliuua3AbWblCJJLjhvcSe3rl3CT+5Yw+HhSZS0bVlVjIPGgVvq33KA/SVjePZgDCrGOPcxizbLZCWi1XfZ>> "%TMP%\adexe_icon.b64"
echo /d3rWNa9kCCyqaOK1SS7f/HT5/Ozu66kNFphFqefJrFVhWcPxkfOyPrEzrvh3k2Sab9XyyNhvSMm1SSa7LnnepZ2L6QcRDiO>> "%TMP%\adexe_icon.b64"
echo gZSvkE6ZG8aW1ozLA7tfZOP2J5nXnkn2DjOSbCjZvKeV0dsPP3z7fVWbjxRzPUXfGne3Y+Mhcf2CRkFNEbEqbRmPpd0LAcj6>> "%TMP%\adexe_icon.b64"
echo zR3me1MdujXLTyOe6ljEM92F6iGfjYes4+6mp+gDEVSr0T6xrCrakb0bX89v2HGlk809brLZmsesjghBGHP3L58m4znT28XZ>> "%TMP%\adexe_icon.b64"
echo wqoiwIF3R8m2eEff/aOOWfOextFwPDl65ciuza+zqujSn4TRpg+6FWV4eDK129SFayjks1irTO3tmzjoriLFpwZVH/bcE3OY>> "%TMP%\adexe_icon.b64"
echo qaqEsaW6/Wn+U4MqPkAfe9THB+Bzm/8CQhXw84SQdnYAAAAASUVORK5CYIKJUE5HDQoaCgAAAA1JSERSAAAAQAAAAEAIBgAA>> "%TMP%\adexe_icon.b64"
echo AKppcd4AAAGvSURBVHic7ZtRcsMgDERppgdo7tYcoj1Qc4j2bs0N2i8yCQZbwIq1kd5nBtTVIlPB2CE4tnlpmfT2/vWHFoLg>> "%TMP%\adexe_icon.b64"
echo 9vNZnY94wl6TLiE14yQZdLTkQ5BrXnXpiInnWKuGYgXMknwI67lkDZgp+UgpJ9EeMDMLA2Zc/Ugut9PWgNlIc/RHgC2Azd0A>> "%TMP%\adexe_icon.b64"
echo C+UfeczVK4AtgI15A17RAX+/Pxa/nS/X3cRLuR8SejfBnNCUGuHoeCnxgAR5BCRimePW6DagVsTWeHS8Lcxvgl0GtLpfmoeO>> "%TMP%\adexe_icon.b64"
echo J8ErgC2AjRvAFsCmy4DWRqQ0Dx1PglcAWwAb831A02EI0YNHzpcrPJ6E5sMQUuwe4vkeUDMYvVpa1Oj0CmALYFN1J4i4i9O+>> "%TMP%\adexe_icon.b64"
echo 6qplaAWMvOqSMsyA0VddUoYYwOjwpJjfBNUN6F1F7SrwCmALYOMGsAWwUTegt6vT7gq9Akb8EcZtrxTzFfD0FrXGm2KIRgZd>> "%TMP%\adexe_icon.b64"
echo CY9vj6tWAKqL0+wG1QxgX3ZKeTKg5ZubHFpiEXHTHBcV0GuC9uGlJ34uN/P/BbIGoB6FPVHKyfxHU6KVPqoRkkoW7QFHfCSk>> "%TMP%\adexe_icon.b64"
echo ms1/OutY5x+YDLesNXHCWQAAAABJRU5ErkJggg==>> "%TMP%\adexe_icon.b64"
"%PYTHON%" %PYARGS% -c "import base64,pathlib;pathlib.Path('app_icon.ico').write_bytes(base64.b64decode(pathlib.Path(r'%TMP%\adexe_icon.b64').read_text()))"

echo.
echo [4/4] Compilation de l'executable (1 a 2 minutes)...
"%PYTHON%" %PYARGS% -m PyInstaller --noconfirm --onefile --windowed --icon app_icon.ico %CRYPTO_FLAG% --name ADGroupExporter ad_group_exporter.py %*
if errorlevel 1 (
    echo ERREUR : la compilation a echoue.
    pause
    exit /b 1
)

copy /y dist\ADGroupExporter.exe ADGroupExporter.exe >nul
if errorlevel 1 (
    echo ERREUR : impossible de remplacer ADGroupExporter.exe.
    echo L'ancienne version est probablement encore ouverte : fermez
    echo completement l'application, puis relancez ce script.
    pause
    exit /b 1
)
echo.
echo ============================================================
echo  SUCCES : ADGroupExporter.exe cree dans %~dp0
echo ============================================================
if not defined AD_NO_OPEN start "" explorer /select,"%~dp0ADGroupExporter.exe"
if not defined AD_NO_PAUSE pause
endlocal
