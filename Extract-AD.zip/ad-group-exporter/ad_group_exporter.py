"""
ad_group_exporter.py — version « fichier unique » de l'application.

Regroupe le moteur LDAP/AD et l'interface graphique pour permettre de
construire l'exécutable avec seulement ce fichier + creer_exe.bat.
Équivalent fonctionnel de ad_core.py + app.py.

Lancement :  python ad_group_exporter.py            (interface)
             python ad_group_exporter.py --cli ...  (export sans interface)
"""
from __future__ import annotations

import base64
import csv
import datetime as _dt
import hashlib
import os
import re
import socket
import ssl
from dataclasses import dataclass, field, asdict
from typing import Any, Callable, Dict, Iterable, Iterator, List, Optional, Sequence, Tuple

try:
    import ldap3
    from ldap3 import ALL, NTLM, SIMPLE, Connection, Server, Tls, SUBTREE
    from ldap3.core.exceptions import (
        LDAPBindError,
        LDAPCommunicationError,
        LDAPException,
        LDAPSocketOpenError,
    )
    LDAP3_AVAILABLE = True
    LDAP3_VERSION = ldap3.__version__
except ImportError:  # pragma: no cover - géré proprement par l'interface
    # Alias minimaux pour que le module reste importable sans ldap3 ;
    # connect() lève une ADError explicite et l'interface affiche le message.
    LDAP3_AVAILABLE = False
    LDAP3_VERSION = ""
    SUBTREE = 2
    ALL = "ALL"
    NTLM = "NTLM"
    SIMPLE = "SIMPLE"
    Connection = None
    Server = None
    Tls = None

    class LDAPException(Exception):
        pass

    LDAPBindError = LDAPException
    LDAPCommunicationError = LDAPException
    LDAPSocketOpenError = LDAPException

# --------------------------------------------------------------------------- #
# MD4 de secours (authentification NTLM)
# --------------------------------------------------------------------------- #
#
# NTLM exige MD4 (le « NT hash »). Or OpenSSL 3, livré avec les Python
# récents, ne fournit plus MD4 : hashlib.new('MD4', ...) lève ValueError,
# exactement l'erreur vue sur les postes Windows (« unsupported hash type
# MD4 »), et pycryptodome (module Crypto) n'est pas toujours installé.
# On installe donc un MD4 pur Python (RFC 1320) derrière hashlib.new,
# uniquement si la plateforme n'en a pas.


def _rotl32(value: int, shift: int) -> int:
    return ((value << shift) | (value >> (32 - shift))) & 0xFFFFFFFF


class PureMD4:
    """MD4 (RFC 1320) — API minimale de hashlib.new utilisée par ldap3."""

    def __init__(self, data: bytes = b"") -> None:
        self._a0, self._b0, self._c0, self._d0 = (
            0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476)
        self._buffer = b""
        self._bitlen = 0
        if data:
            self.update(data)

    def update(self, data: bytes) -> None:
        self._buffer += bytes(data)
        self._bitlen += 8 * len(data)
        while len(self._buffer) >= 64:
            self._process(self._buffer[:64])
            self._buffer = self._buffer[64:]

    def _process(self, block: bytes) -> None:
        x = [int.from_bytes(block[i:i + 4], "little") for i in range(0, 64, 4)]
        a, b, c, d = self._a0, self._b0, self._c0, self._d0

        for i in range(16):
            f = (b & c) | (~b & d)
            k = i
            s = (3, 7, 11, 19)[i % 4]
            a = _rotl32((a + f + x[k]) & 0xFFFFFFFF, s)
            a, b, c, d = d, a, b, c
        for i in range(16):
            g = (b & c) | (b & d) | (c & d)
            k = (i % 4) * 4 + i // 4
            s = (3, 5, 9, 13)[i % 4]
            a = _rotl32((a + g + x[k] + 0x5A827999) & 0xFFFFFFFF, s)
            a, b, c, d = d, a, b, c
        for i in range(16):
            h = b ^ c ^ d
            k = [0, 8, 4, 12, 2, 10, 6, 14, 1, 9, 5, 13, 3, 11, 7, 15][i]
            s = (3, 9, 11, 15)[i % 4]
            a = _rotl32((a + h + x[k] + 0x6ED9EBA1) & 0xFFFFFFFF, s)
            a, b, c, d = d, a, b, c

        self._a0 = (self._a0 + a) & 0xFFFFFFFF
        self._b0 = (self._b0 + b) & 0xFFFFFFFF
        self._c0 = (self._c0 + c) & 0xFFFFFFFF
        self._d0 = (self._d0 + d) & 0xFFFFFFFF

    def digest(self) -> bytes:
        # copie d'état : digest() ne doit pas modifier l'objet courant
        clone = PureMD4.__new__(PureMD4)
        clone._a0, clone._b0, clone._c0, clone._d0 = (
            self._a0, self._b0, self._c0, self._d0)
        clone._buffer = self._buffer
        clone._bitlen = self._bitlen
        msg = clone._buffer
        pad = (64 - ((len(msg) + 9) % 64)) % 64
        msg += b"\x80" + b"\x00" * pad + clone._bitlen.to_bytes(8, "little")
        for i in range(0, len(msg), 64):
            clone._process(msg[i:i + 64])
        return b"".join(w.to_bytes(4, "little")
                        for w in (clone._a0, clone._b0, clone._c0, clone._d0))

    def hexdigest(self) -> str:
        return self.digest().hex()


def _platform_has_md4() -> bool:
    try:
        hashlib.new("md4")
        return True
    except (ValueError, TypeError):
        return False


def install_md4_fallback() -> bool:
    """
    Branche PureMD4 derrière hashlib.new si la plateforme n'a pas MD4.

    Renvoie True si le secours a été installé. C'est le chemin qu'emprunte
    ldap3 pour l'authentification NTLM quand pycryptodome est absent.
    """
    if _platform_has_md4() or getattr(hashlib.new, "_ad_md4_fallback", False):
        return False
    original = hashlib.new

    def _new(name, data=b"", **kwargs):
        if isinstance(name, str) and name.lower() == "md4":
            return PureMD4(data)
        return original(name, data, **kwargs)

    _new._ad_md4_fallback = True
    hashlib.new = _new
    return True


install_md4_fallback()


# --------------------------------------------------------------------------- #
# Constantes
# --------------------------------------------------------------------------- #

EPOCH_1601 = _dt.datetime(1601, 1, 1)
PAGE_SIZE = 1000  # taille max d'une page LDAP côté AD

USER_ATTRS = [
    "sAMAccountName",
    "displayName",
    "cn",
    "name",
    "userPrincipalName",
    "mail",
    "title",
    "department",
    "company",
    "manager",
    "telephoneNumber",
    "distinguishedName",
    "whenCreated",
    "lastLogon",
    "lastLogonTimestamp",
    "pwdLastSet",
    "userAccountControl",
    "objectSid",
    "objectGUID",
    "memberOf",
    "description",
]

# Ordre des colonnes pour l'affichage / l'export
EXPORT_COLUMNS: List[Tuple[str, str]] = [
    ("samaccountname", "Compte (sAMAccountName)"),
    ("displayname", "Nom affiché"),
    ("userprincipalname", "UPN"),
    ("mail", "E-mail"),
    ("title", "Fonction"),
    ("department", "Service"),
    ("company", "Société"),
    ("manager", "Responsable"),
    ("telephone", "Téléphone"),
    ("etat", "État"),
    ("type", "Type d'objet"),
    ("appartenance", "Appartenance"),
    ("groupes_imbriques", "Via groupe(s) imbriqué(s)"),
    ("derniere_connexion", "Dernière connexion"),
    ("creation", "Créé le"),
    ("distinguishedname", "DistinguishedName"),
]

UAC_DISABLED = 0x0002
UAC_LOCKOUT = 0x0010
UAC_PASSWD_NOTREQD = 0x0020
UAC_PASSWD_CANT_CHANGE = 0x0040
UAC_NORMAL_ACCOUNT = 0x0200
UAC_DONT_EXPIRE_PASSWORD = 0x10000
UAC_PASSWORD_EXPIRED = 0x800000


# --------------------------------------------------------------------------- #
# Erreurs
# --------------------------------------------------------------------------- #


class ADError(Exception):
    """Erreur métier lisible par l'utilisateur final."""


# --------------------------------------------------------------------------- #
# Objets de données
# --------------------------------------------------------------------------- #


@dataclass
class AdSettings:
    """Paramètres de connexion persistés (jamais le mot de passe)."""

    server: str = ""
    port: str = ""
    mode: str = "ldaps"            # ldap | ldaps | starttls
    verify_cert: bool = True
    base_dn: str = ""
    domain: str = ""
    auth: str = "sso"              # sso | ntlm | simple
    username: str = ""
    remember_user: bool = True

    @classmethod
    def load(cls, path: str) -> "AdSettings":
        import json

        try:
            with open(path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
        except (OSError, ValueError):
            return cls()
        known = {f for f in cls.__dataclass_fields__}  # type: ignore[attr-defined]
        return cls(**{k: v for k, v in data.items() if k in known})

    def save(self, path: str) -> bool:
        """Enregistre les réglages (jamais le mot de passe). Renvoie True si écrit."""
        import json

        try:
            parent = os.path.dirname(path)
            if parent:
                os.makedirs(parent, exist_ok=True)
            with open(path, "w", encoding="utf-8") as fh:
                json.dump(asdict(self), fh, indent=2, ensure_ascii=False)
            return True
        except OSError:
            return False


@dataclass
class Member:
    """Un membre de groupe, utilisateur / groupe / ordinateur / contact."""

    distinguishedname: str = ""
    samaccountname: str = ""
    displayname: str = ""
    name: str = ""
    userprincipalname: str = ""
    mail: str = ""
    title: str = ""
    department: str = ""
    company: str = ""
    manager: str = ""
    telephone: str = ""
    etat: str = ""
    type: str = ""
    appartenance: str = ""
    groupes_imbriques: str = ""
    derniere_connexion: str = ""
    creation: str = ""
    uac: int = 0
    sid: str = ""
    raw: Dict[str, Any] = field(default_factory=dict)

    def row(self, columns: Optional[Sequence[str]] = None) -> List[str]:
        cols = columns or [k for k, _ in EXPORT_COLUMNS]
        return [str(getattr(self, c, "") or "") for c in cols]


@dataclass
class GroupInfo:
    dn: str = ""
    name: str = ""
    samaccountname: str = ""
    description: str = ""
    group_type: str = ""
    raw: Dict[str, Any] = field(default_factory=dict)


# --------------------------------------------------------------------------- #
# Utilitaires LDAP purs (testables sans serveur)
# --------------------------------------------------------------------------- #


def escape_ldap_filter(value: str) -> str:
    """
    Échappe une valeur pour un filtre LDAP (RFC 4515) — anti-injection.
    Les caractères non ASCII sont échappés octet par octet en UTF-8,
    comme l'exige la RFC : 'é' -> '\\c3\\a9'.
    """
    out = []
    for ch in value:
        code = ord(ch)
        if ch in r"\*()" or code < 0x20 or code > 0x7E:
            out.append("".join("\\%02x" % b for b in ch.encode("utf-8")))
        else:
            out.append(ch)
    return "".join(out)


def escape_filter_pattern(pattern: str) -> str:
    """Échappe une valeur de filtre LDAP en préservant les jokers * et ?."""
    out = []
    for part in re.split(r"([*?])", pattern or ""):
        out.append(part if part in ("*", "?") else escape_ldap_filter(part))
    return "".join(out)


def split_dn(dn: str) -> List[str]:
    """Découpe un DN en RDN en respectant les virgules échappées / entre guillemets."""
    parts: List[str] = []
    current: List[str] = []
    escaped = False
    in_quotes = False
    for ch in dn:
        if escaped:
            current.append(ch)
            escaped = False
            continue
        if ch == "\\":
            current.append(ch)
            escaped = True
            continue
        if ch == '"':
            in_quotes = not in_quotes
        if ch == "," and not in_quotes:
            parts.append("".join(current).strip())
            current = []
            continue
        current.append(ch)
    tail = "".join(current).strip()
    if tail:
        parts.append(tail)
    return parts


def _parse_rdn(rdn: str) -> Tuple[str, str]:
    key, sep, value = rdn.partition("=")
    if not sep:
        return "", ""
    value = value.strip()
    if len(value) >= 2 and value.startswith('"') and value.endswith('"'):
        value = value[1:-1]
    out: List[str] = []
    escaped = False
    for ch in value:
        if escaped:
            if ch == "n":
                out.append("\n")
            elif ch == "r":
                out.append("\r")
            else:
                out.append(ch)
            escaped = False
            continue
        if ch == "\\":
            escaped = True
            continue
        out.append(ch)
    return key.strip().lower(), "".join(out)


def parse_dn(dn: str) -> List[Tuple[str, str]]:
    """[(clé, valeur), ...] du plus spécifique au moins spécifique."""
    return [_parse_rdn(r) for r in split_dn(dn)]


def dn_value(dn: str, key: str) -> str:
    """Valeur d'un attribut du DN (ex. dn_value(dn, 'ou'))."""
    for k, v in parse_dn(dn):
        if k == key.lower():
            return v
    return ""


def build_dn(components: Iterable[Tuple[str, str]]) -> str:
    def esc(v: str) -> str:
        return re.sub(r"([\\,=+<>#;\"])", r"\\\1", v)

    return ",".join("%s=%s" % (k, esc(v)) for k, v in components)


def guess_base_dn(host: str = "", domain: str = "", username: str = "",
                  dns_host_name: str = "") -> Tuple[str, str]:
    """
    Déduit une base de recherche (et sa provenance) sans interroger
    l'annuaire : domaine DNS saisi, domaine de la machine, FQDN du
    serveur annoncé ou saisi, UPN du compte. Retourne ("", "") si
    rien ne permet de conclure.
    """
    candidates: List[Tuple[str, str]] = []
    if (domain or "").strip():
        candidates.append((domain.strip(), "domaine DNS saisi"))
    local = guess_local_domain()
    if local:
        candidates.append((local, "domaine DNS de la machine"))
    if is_fqdn(dns_host_name or ""):
        candidates.append(((dns_host_name or "").split(".", 1)[1], "FQDN annoncé par le serveur"))
    if is_fqdn(host or ""):
        candidates.append(((host or "").split(".", 1)[1], "FQDN du serveur saisi"))
    if "@" in (username or ""):
        candidates.append(((username or "").split("@", 1)[1], "UPN du compte"))
    for dom, src in candidates:
        base = domain_to_base_dn(dom)
        if base:
            return base, src
    return "", ""


def domain_to_base_dn(domain: str) -> str:
    """'corp.exemple.fr' -> 'DC=corp,DC=exemple,DC=fr'."""
    domain = (domain or "").strip().strip(".")
    if not domain:
        return ""
    return build_dn(("DC", part) for part in domain.split("."))


def base_dn_to_domain(base_dn: str) -> str:
    """'DC=corp,DC=exemple,DC=fr' -> 'corp.exemple.fr'."""
    return ".".join(v for k, v in parse_dn(base_dn or "") if k == "dc")


def is_ipv4(name: str) -> bool:
    return bool(re.match(r"^\d{1,3}(\.\d{1,3}){3}$", (name or "").strip()))


def is_fqdn(name: str) -> bool:
    """Un nom contient un point et n'est pas une IP => déjà qualifié."""
    name = (name or "").strip()
    return "." in name and not is_ipv4(name)


def resolve_host(name: str, dns_domain: str = "") -> str:
    """Complète un nom NetBIOS en FQDN si nécessaire."""
    name = (name or "").strip()
    if not name or is_fqdn(name) or is_ipv4(name):
        return name
    if dns_domain:
        return "%s.%s" % (name, dns_domain.lstrip("."))
    return name


def attr_str(entry: Dict[str, Any], key: str) -> str:
    """Récupère une valeur d'attribut ldap3 sous forme de str, quel que soit le type."""
    if not entry:
        return ""
    value = entry.get(key)
    if value is None:
        # ldap3 renvoie parfois les clés en minuscules
        lowered = {k.lower(): v for k, v in entry.items()}
        value = lowered.get(key.lower())
    if value is None:
        return ""
    if isinstance(value, (list, tuple)):
        if not value:
            return ""
        value = value[0]
    if isinstance(value, bytes):
        try:
            return value.decode("utf-8")
        except UnicodeDecodeError:
            return value.decode("latin-1", "replace")
    return str(value)


def attr_list(entry: Dict[str, Any], key: str) -> List[str]:
    if not entry:
        return []
    lowered = {k.lower(): v for k, v in entry.items()}
    value = entry.get(key, lowered.get(key.lower()))
    if value is None:
        return []
    if not isinstance(value, (list, tuple)):
        value = [value]
    out = []
    for item in value:
        if isinstance(item, bytes):
            item = item.decode("utf-8", "replace")
        out.append(str(item))
    return out


def merge_ranged_attrs(entry: Dict[str, Any], attr: str) -> List[str]:
    """
    Fusionne les attributs « paginés » d'AD (member;range=0-1499,
    member;range=1500-2999, ...) en une seule liste.

    ldap3 le fait déjà grâce à auto_range=True ; cette fonction est une
    sécurité supplémentaire si un serveur renvoie les plages brutes.
    """
    direct = attr_list(entry, attr)
    ranged: List[str] = []
    prefix = attr.lower() + ";"
    for key, value in (entry or {}).items():
        lk = key.lower()
        if not lk.startswith(prefix):
            continue
        if lk.endswith("-*") or not re.search(r"range=\d+-", lk):
            continue
        if isinstance(value, (list, tuple)):
            ranged.extend(v.decode("utf-8", "replace") if isinstance(v, bytes) else str(v) for v in value)
        else:
            ranged.append(value.decode("utf-8", "replace") if isinstance(value, bytes) else str(value))
    if direct and ranged:
        seen = set(direct)
        return direct + [d for d in ranged if d not in seen]
    return direct or ranged


def filetime_to_datetime(value: Any) -> Optional[_dt.datetime]:
    """Convertit un FILETIME Windows (100 ns depuis 1601) en datetime."""
    try:
        ticks = int(str(value).strip())
    except (TypeError, ValueError):
        return None
    if ticks <= 0 or ticks >= 2650467744000000000:  # ~ 9999-12-31
        return None
    return EPOCH_1601 + _dt.timedelta(microseconds=ticks // 10)


def fmt_ad_datetime(value: Any) -> str:
    """
    '20230417082511.0Z' (generalizedTime) ou FILETIME -> '17/04/2023 08:25'.
    Un FILETIME à 0 (jamais connecté / mot de passe jamais défini) -> 'Jamais'.
    """
    if value in (None, "", []):
        return ""
    text = value if isinstance(value, str) else attr_str({"v": value}, "v")
    text = text.strip()
    if not text:
        return ""

    # Un FILETIME est un entier long (>= 15 chiffres pour toute date AD réelle) :
    # on le traite avant le generalizedTime, dont les 14 premiers chiffres
    # pourraient sinon être lus comme une date.
    if text.isdigit():
        ticks = int(text)
        if ticks == 0:
            return "Jamais"
        dt = filetime_to_datetime(ticks)
        return dt.strftime("%d/%m/%Y %H:%M") if dt else ""

    m = re.match(r"^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})(.*Z?)$", text)
    if m:
        fields = [int(g) for g in m.groups()[:6]]
        is_utc = m.group(7).strip().endswith("Z")
        try:
            dt = _dt.datetime(*fields)
        except ValueError:
            # Mois/jour invalides : c'était sans doute un FILETIME court.
            dt = filetime_to_datetime(text)
            return dt.strftime("%d/%m/%Y %H:%M") if dt else text
        if is_utc:
            # whenCreated est stocké en UTC : on affiche l'heure locale du poste.
            dt = dt.replace(tzinfo=_dt.timezone.utc).astimezone().replace(tzinfo=None)
        return dt.strftime("%d/%m/%Y %H:%M")
    return ""


def decode_account_state(uac: int, pwd_last_set: Any = None) -> str:
    """Libellé français lisible à partir du bitmask userAccountControl."""
    try:
        uac = int(uac or 0)
    except (TypeError, ValueError):
        return ""
    if uac == 0:
        return ""
    if uac & UAC_DISABLED:
        return "Désactivé"
    if uac & UAC_LOCKOUT:
        return "Verrouillé"
    if uac & UAC_PASSWORD_EXPIRED:
        return "Mot de passe expiré"
    if pwd_last_set is not None and str(pwd_last_set).strip() in ("0", ""):
        if not (uac & UAC_DONT_EXPIRE_PASSWORD):
            return "Actif (MDP à définir)"
    return "Actif"


def decode_sid(raw: Any) -> str:
    """
    Convertit objectSid en forme lisible S-1-5-21-...

    Selon le serveur et la configuration, la valeur arrive sous forme d'octets,
    d'octets décodés en latin-1 (chaîne « brute ») ou de base64.
    """
    if raw is None:
        return ""
    if isinstance(raw, str):
        text = raw.strip()
        if not text:
            return ""
        if text.upper().startswith("S-"):
            return text
        # Chaîne d'octets bruts (cas courant quand le serveur n'annonce pas
        # l'attribut comme binaire) : on repasse par latin-1, sans perte.
        if any(ord(ch) > 127 for ch in text) or text.startswith("\x01"):
            raw = text.encode("latin-1", "replace")
        else:
            try:
                raw = base64.b64decode(text, validate=True)
            except (ValueError, TypeError):
                return ""
    data = bytes(raw)
    if len(data) < 8:
        return ""
    revision = data[0]
    sub_count = data[1]
    # Les 6 octets d'autorité sont en big-endian (S-1-5-... -> 5) ;
    # les sous-autorités suivantes sont en little-endian (S-1-5-21-... -> 21).
    authority = int.from_bytes(data[2:8], "big")
    subs = [
        int.from_bytes(data[8 + 4 * i: 8 + 4 * (i + 1)], "little")
        for i in range(sub_count)
        if len(data) >= 12 + 4 * i
    ]
    return "S-%d-%d-%s" % (revision, authority, "-".join(str(s) for s in subs))


def sid_from_dn(dn: str) -> str:
    """
    Extrait le SID d'un DN de type foreignSecurityPrincipal :
    'CN=S-1-5-21-...,CN=ForeignSecurityPrincipals,DC=...' -> 'S-1-5-21-...'
    """
    cn = dn_value(dn, "cn")
    return cn if cn.upper().startswith("S-") else ""


def raw_bytes(data: Dict[str, Any], key: str) -> Any:
    """Récupère la valeur brute (bytes de préférence) d'un attribut."""
    lowered = {k.lower(): v for k, v in (data or {}).items()}
    value = data.get(key, lowered.get(key.lower())) if data else None
    if isinstance(value, (list, tuple)):
        return value[0] if value else None
    return value


def classify_object(classes: Sequence[str]) -> str:
    lowered = {c.lower() for c in classes}
    names = {c for c in classes}
    # Un ordinateur AD hérite de la classe 'user' : on le teste en premier.
    if "computer" in lowered:
        return "Ordinateur"
    if "msDS-groupManagedServiceAccount" in names:
        return "gMSA"
    if "user" in lowered:
        return "Utilisateur"
    if "group" in lowered:
        return "Groupe"
    if "contact" in lowered or "msExchMailbox" in {c for c in classes}:
        return "Contact"
    if "foreignsecurityprincipal" in lowered:
        return "Principal externe"
    return ", ".join(classes) or "Inconnu"


def default_port(mode: str) -> int:
    return {"ldaps": 636, "starttls": 389}.get((mode or "ldap").lower(), 389)


def settings_path(app_name: str = "ADGroupExporter") -> str:
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    return os.path.join(base, app_name, "settings.json")


def guess_local_domain() -> str:
    """Devine le domaine DNS du poste (Windows surtout)."""
    for var in ("USERDNSDOMAIN", "USERDOMAIN_FQDN"):
        val = os.environ.get(var, "").strip()
        if val and "." in val:
            return val
    userdom = os.environ.get("USERDOMAIN", "").strip()
    if userdom and "." in userdom:
        return userdom
    return ""


def split_credentials(username: str) -> Tuple[str, str]:
    """'DOM\\user', 'user@corp.fr' ou 'user' -> (domaine, identifiant court)."""
    username = (username or "").strip()
    if "\\" in username:
        dom, _, user = username.partition("\\")
        return dom.strip(), user.strip()
    if "@" in username:
        user, _, upn_domain = username.partition("@")
        return upn_domain.strip(), user.strip()
    return "", username


# --------------------------------------------------------------------------- #
# Client Active Directory
# --------------------------------------------------------------------------- #


class AdClient:
    """Client LDAP/LDAPS vers un contrôleur de domaine Active Directory."""

    def __init__(
        self,
        host: str,
        port: Optional[int] = None,
        mode: str = "ldaps",
        verify_cert: bool = True,
        username: Optional[str] = None,
        password: Optional[str] = None,
        auth: str = "sso",
        base_dn: str = "",
        domain: str = "",
        timeout: int = 15,
        page_size: int = PAGE_SIZE,
        scan_cap: int = 50000,
    ) -> None:
        if not LDAP3_AVAILABLE:
            raise ADError(
                "La bibliothèque 'ldap3' n'est pas installée.\n"
                "Installez-la avec :  pip install ldap3"
            )
        self.mode = (mode or "ldap").lower()
        self.verify_cert = bool(verify_cert)
        self.auth = (auth or "sso").lower()
        self.username = username or ""
        self.password = password or ""
        self.timeout = timeout
        self.page_size = page_size
        self.scan_cap = int(scan_cap)
        self.base_dn = (base_dn or "").strip()
        self.domain_hint = (domain or "").strip()
        self.host = (host or "").strip()
        self.port = int(port) if port else default_port(self.mode)
        self.default_naming_context = ""
        self.root_domain_naming_context = ""
        self.dns_host_name = ""
        self._known_attributes: set = set()
        self._conn: Optional[Any] = None

    # -- connexion --------------------------------------------------------- #

    def _build_tls(self) -> Optional[Any]:
        if self.mode == "ldap":
            return None
        if self.verify_cert:
            return Tls(validate=ssl.CERT_REQUIRED, version=ssl.PROTOCOL_TLS_CLIENT)
        return Tls(validate=ssl.CERT_NONE, version=ssl.PROTOCOL_TLS_CLIENT)

    def _build_server(self) -> Any:
        tls = self._build_tls()
        use_ssl = self.mode == "ldaps"
        return Server(
            self.host,
            port=self.port,
            use_ssl=use_ssl,
            tls=tls,
            get_info=ALL,
            connect_timeout=self.timeout,
        )

    def _bind_kwargs(self) -> Dict[str, Any]:
        if self.auth == "sso":
            try:
                from ldap3 import KERBEROS  # disponible sur Windows (SSPI)
                return {"authentication": KERBEROS}
            except ImportError:
                return {"authentication": NTLM, "user": self.username, "password": self.password}
        if self.auth == "ntlm":
            return {"authentication": NTLM, "user": self.username, "password": self.password}
        if not self.username:
            # Bind anonyme (lecture seule) : utile sur un annuaire qui l'autorise.
            from ldap3 import ANONYMOUS
            return {"authentication": ANONYMOUS}
        return {"authentication": SIMPLE, "user": self.username, "password": self.password}

    def _open_connection(self, kwargs: Dict[str, Any]) -> Any:
        server = self._build_server()
        # check_names=False : ldap3 refuse sinon un filtre dont la valeur
        # (ex. objectClass=group) n'existe pas dans le schéma publié par le
        # serveur — fréquent sur AD comme sur les annuaires au schéma étendu.
        conn = Connection(server, auto_bind=False, receive_timeout=self.timeout,
                          check_names=False, **kwargs)
        if self.mode == "starttls":
            if not conn.start_tls():
                result = conn.result or {}
                raise ADError(
                    "Échec du démarrage StartTLS sur %s:%s (%s)."
                    % (self.host, self.port, result.get("description", "raison inconnue"))
                )
        conn.bind()
        if not conn.bound:
            result = conn.result or {}
            raise LDAPBindError("%s (code %s)"
                                % (result.get("description", "bind refusé"), result.get("result", "?")))
        return conn

    def connect(self) -> None:
        kwargs = self._bind_kwargs()
        conn = None
        try:
            try:
                conn = self._open_connection(kwargs)
            except LDAPBindError:
                # SSO indisponible ou refusée : on retente avec le compte saisi.
                if self.auth == "sso" and self.username and self.password:
                    conn = self._open_connection(
                        {"authentication": NTLM, "user": self.username, "password": self.password})
                else:
                    raise
        except LDAPBindError as exc:
            raise ADError(
                "Authentification refusée par %s.\n"
                "Vérifiez le compte (format DOMAINE\\utilisateur) et le mot de passe.\n"
                "Détail : %s" % (self.host, exc)
            ) from exc
        except (LDAPSocketOpenError, LDAPCommunicationError, socket.gaierror, OSError) as exc:
            raise ADError(
                "Impossible de joindre %s:%s.\n"
                "Vérifiez le nom du contrôleur de domaine, le port et le pare-feu.\n"
                "Détail : %s" % (self.host, self.port, exc)
            ) from exc
        except LDAPException as exc:
            raise ADError("Erreur LDAP pendant la connexion : %s" % exc) from exc

        if not conn.bound:
            raise ADError("Connexion établie mais session non authentifiée (%s)." % conn.result)
        self._conn = conn
        self._read_root_dse(conn)

    def _read_root_dse(self, conn: Any) -> None:
        try:
            if conn.search("", "(objectClass=*)", search_scope="BASE",
                           attributes=["defaultNamingContext", "dnsHostName", "rootDomainNamingContext"]):
                entry = conn.entries[0]
                self.default_naming_context = str(getattr(entry, "defaultNamingContext", "") or "")
                self.root_domain_naming_context = str(getattr(entry, "rootDomainNamingContext", "") or "")
                self.dns_host_name = str(getattr(entry, "dnsHostName", "") or "")
        except LDAPException:
            self.default_naming_context = ""
        if not self.base_dn:
            self.base_dn = self.default_naming_context
        self._known_attributes = self._supported_attributes(conn)

    def _supported_attributes(self, conn: Any) -> set:
        """
        Ensemble des noms d'attributs publiés par le serveur.

        Sert à ne demander que des attributs réellement supportés : un serveur
        LDAP qui ne connaît pas un attribut (objectGUID sur un annuaire non AD
        par exemple) refuse la recherche entière.
        """
        try:
            schema = conn.server.schema
            types = getattr(schema, "attribute_types", None) or {}
            names = set()
            for name in types:
                names.add(name.lower())
                info = types[name]
                for alias in getattr(info, "name", None) or []:
                    names.add(str(alias).lower())
            return names
        except (LDAPException, AttributeError):
            return set()

    # -- helpers ----------------------------------------------------------- #

    @property
    def connection(self) -> Any:
        if self._conn is None:
            raise ADError("Non connecté à l'Active Directory.")
        return self._conn

    def close(self) -> None:
        if self._conn is not None:
            try:
                self._conn.unbind()
            except LDAPException:
                pass
            self._conn = None

    def __enter__(self) -> "AdClient":
        self.connect()
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    def effective_base_dn(self) -> str:
        """
        Base de recherche, par ordre de confiance :
        champ saisi, rootDSE (defaultNamingContext puis racine de la forêt),
        puis déduction depuis le domaine DNS saisi, le FQDN du serveur ou
        l'UPN du compte — certains AD restreignent le rootDSE.
        """
        return (self.base_dn or self.default_naming_context
                or self.root_domain_naming_context or self._base_from_hints())

    def _base_from_hints(self) -> str:
        return guess_base_dn(host=self.host, domain=self.domain_hint,
                             username=self.username,
                             dns_host_name=self.dns_host_name)[0]

    def base_dn_source(self) -> str:
        if self.base_dn:
            return "saisie manuelle"
        if self.default_naming_context:
            return "rootDSE (defaultNamingContext)"
        if self.root_domain_naming_context:
            return "rootDSE (racine de la forêt)"
        if self._base_from_hints():
            return "déduite du domaine"
        return ""

    def _select_attributes(self, attributes: Sequence[str]) -> List[str]:
        """
        Ne conserve que les attributs publiés par le serveur.

        Garde-fou : si le serveur annonce un schéma très incomplet, on ne filtre
        rien plutôt que de perdre silencieusement des colonnes.
        """
        known = getattr(self, "_known_attributes", None)
        if not known:
            return list(attributes)
        kept = [a for a in attributes if a.lower() in known]
        if len(kept) * 2 < len(attributes):
            return list(attributes)
        return kept

    def _search(self, base: str, flt: str, attributes: Sequence[str],
                scope: str = SUBTREE, limit: Optional[int] = None) -> List[Any]:
        wanted = self._select_attributes(attributes) or list(attributes)
        base = base or self.effective_base_dn()
        if not base:
            raise ADError(
                "Base de recherche introuvable : le rootDSE ne l'annonce pas et "
                "aucun domaine n'a pu être déduit.\n"
                "Renseignez le champ « Base de recherche (DN) » "
                "(ex. DC=societe,DC=fr) puis relancez.")
        try:
            self.connection.search(
                search_base=base,
                search_filter=flt,
                search_scope=scope,
                attributes=wanted,
                paged_size=self.page_size,
            )
        except LDAPException as exc:
            raise ADError("Recherche LDAP en échec : %s" % exc) from exc
        entries = list(self.connection.entries)
        return entries[:limit] if limit else entries

    @staticmethod
    def _entry_dict(entry: Any) -> Dict[str, Any]:
        try:
            data = dict(entry.entry_attributes_as_dict)
        except Exception:  # pragma: no cover
            data = {str(k): list(v) for k, v in dict(entry).items()}
        # distinguishedName est une donnée opérationnelle : la plupart des
        # serveurs ne la renvoient pas comme attribut, il faut lire le DN
        # de l'entrée elle-même.
        dn = ""
        try:
            dn = str(entry.entry_dn or "")
        except Exception:  # pragma: no cover
            dn = ""
        if dn and not data.get("distinguishedName"):
            data["distinguishedName"] = [dn]
        return data

    # -- groupes ----------------------------------------------------------- #

    def find_groups(self, pattern: str = "*", base_dn: str = "", limit: int = 500) -> List[GroupInfo]:
        """Recherche des groupes par nom (joker * accepté)."""
        pattern = (pattern or "*").strip() or "*"
        if "*" not in pattern and "?" not in pattern:
            pattern = "*%s*" % pattern
        # On échappe la valeur mais on conserve les jokers * et ? de l'utilisateur.
        # Sur un vrai AD on tape souvent le nom « pre-Windows 2000 »
        # (sAMAccountName) ou le CN : on cherche donc sur les trois attributs.
        p = escape_filter_pattern(pattern)
        riche = ("(&(objectClass=group)"
                 "(|(name=%(p)s)(sAMAccountName=%(p)s)(cn=%(p)s)))") % {"p": p}
        simple = "(&(objectClass=group)(name=%s))" % p
        attrs = ["distinguishedName", "name", "sAMAccountName", "description", "groupType"]
        try:
            entries = self._search(base_dn, riche, attrs)[:limit]
        except ADError:
            # Annuaire non AD qui refuse la sous-chaîne sur sAMAccountName/cn.
            entries = self._search(base_dn, simple, attrs)[:limit]
        groups: List[GroupInfo] = []
        for entry in entries:
            data = self._entry_dict(entry)
            dn = attr_str(data, "distinguishedName")
            groups.append(GroupInfo(
                dn=dn,
                name=attr_str(data, "name") or attr_str(data, "cn") or dn_value(dn, "cn"),
                samaccountname=attr_str(data, "sAMAccountName"),
                description=attr_str(data, "description"),
                group_type=self._group_type(attr_str(data, "groupType")),
                raw=data,
            ))
        groups.sort(key=lambda g: g.name.lower())
        return groups

    def get_group(self, name_or_dn: str, base_dn: str = "") -> Optional[GroupInfo]:
        """Retrouve un groupe par DN exact ou par nom (CN ou sAMAccountName)."""
        value = (name_or_dn or "").strip()
        if not value:
            return None
        looks_like_dn = "=" in value and value.lower().startswith(("cn=", "ou=", "dc="))
        if looks_like_dn:
            # Filtrer sur distinguishedName n'est pas supporté partout :
            # on filtre sur le CN puis on vérifie le DN renvoyé.
            cn = dn_value(value, "cn")
            flt = "(&(objectClass=group)(cn=%s))" % escape_ldap_filter(cn or value)
        else:
            v = escape_ldap_filter(value)
            flt = ("(&(|(objectClass=group))(|(name=%(v)s)(sAMAccountName=%(v)s)(cn=%(v)s)))"
                   % {"v": v})
        entries = self._search(base_dn, flt, [
            "distinguishedName", "name", "sAMAccountName", "description", "groupType", "member",
        ])
        for entry in entries:
            data = self._entry_dict(entry)
            dn = attr_str(data, "distinguishedName")
            if looks_like_dn and dn.lower() != value.lower():
                continue
            return GroupInfo(
                dn=dn,
                name=attr_str(data, "name") or attr_str(data, "cn") or dn_value(dn, "cn"),
                samaccountname=attr_str(data, "sAMAccountName"),
                description=attr_str(data, "description"),
                group_type=self._group_type(attr_str(data, "groupType")),
                raw=data,
            )
        return None

    @staticmethod
    def _group_type(value: str) -> str:
        """
        groupType est un masque de bits :
          0x00000002 Global | 0x00000004 Local de domaine | 0x00000008 Universel
          0x80000000 Groupe de sécurité
        """
        try:
            gt = int(value) & 0xFFFFFFFF
        except (TypeError, ValueError):
            return ""
        if gt == 0:
            return ""
        scope = {
            0x00000002: "Global",
            0x00000004: "Local de domaine",
            0x00000008: "Universel",
        }.get(gt & 0x0000000E, "Portée inconnue")
        kind = "sécurité" if gt & 0x80000000 else "distribution"
        return "%s / %s" % (scope, kind)

    # -- membres ----------------------------------------------------------- #

    def _members_of(self, group_dn: str) -> List[str]:
        entries = self._search(
            group_dn, "(objectClass=*)",
            ["member", "objectClass", "distinguishedName"],
            scope="BASE",
        )
        if not entries:
            return []
        return merge_ranged_attrs(self._entry_dict(entries[0]), "member")

    def list_members(
        self,
        group: str,
        recursive: bool = False,
        progress: Optional[Callable[[str], None]] = None,
    ) -> Tuple[GroupInfo, List[Member]]:
        """
        Liste les membres d'un groupe.

        recursive=True déplie les groupes imbriqués : chaque membre porte la
        mention « Direct » ou « Via <groupe> » et la liste des groupes
        intermédiaires rencontrés.
        """
        def _say(msg: str) -> None:
            if progress:
                progress(msg)

        info = self.get_group(group)
        if info is None:
            raise ADError("Groupe introuvable : %s" % group)

        root_dn = info.dn

        # dn_membre -> (profondeur, premier chemin de groupe vu, groupes imbriqués traversés)
        best: Dict[str, Tuple[int, str, List[str]]] = {}
        visited_groups: set = set()
        queue: List[Tuple[str, int, List[str]]] = [(root_dn, 0, [])]

        while queue:
            current_dn, depth, path = queue.pop(0)
            key = current_dn.lower()
            if key in visited_groups:
                continue
            visited_groups.add(key)
            _say("Lecture des membres de %s…" % (dn_value(current_dn, "cn") or current_dn))
            for member_dn in self._members_of(current_dn):
                mkey = member_dn.lower()
                if mkey == root_dn.lower():
                    continue
                entry_path = path if depth == 0 else path + [dn_value(current_dn, "cn") or current_dn]
                previous = best.get(mkey)
                if previous is None or depth < previous[0]:
                    best[mkey] = (depth, entry_path[0] if entry_path else "", list(entry_path))
                elif depth == previous[0] and entry_path and not previous[1]:
                    best[mkey] = (depth, entry_path[0], list(entry_path))
                if recursive:
                    queue.append((member_dn, depth + 1, entry_path))

        if not best:
            return info, []

        # Récupération des attributs par lots (puis rattrapage global si besoin)
        dn_list = list(best.keys())
        by_dn = self._fetch_attributes(dn_list, _say)

        members: List[Member] = []
        for dn in dn_list:
            depth, via, chain = best[dn]
            data = by_dn.get(dn.lower())
            if data is None:
                # objet supprimé, hors périmètre, ou droits de lecture insuffisants
                fallback_sid = sid_from_dn(dn)
                members.append(Member(
                    distinguishedname=dn,
                    displayname=dn_value(dn, "cn") or "(attributs non accessibles)",
                    type="Principal externe" if fallback_sid else "Inconnu",
                    etat="",
                    appartenance="Direct" if depth == 0 else "Via %s" % via,
                    groupes_imbriques=" > ".join(chain),
                    sid=fallback_sid,
                ))
                continue
            members.append(self._to_member(data, depth, via, chain))

        members.sort(key=lambda m: (m.type != "Utilisateur", (m.samaccountname or m.displayname).lower()))
        return info, members

    # Filtre de balayage de l'annuaire : couvre tous les types d'objets pouvant
    # être membres d'un groupe AD (comptes, gMSA, ordinateurs, groupes, contacts,
    # principaux externes).
    DIRECTORY_FILTER = ("(|(objectClass=user)(objectClass=person)(objectClass=group)"
                        "(objectClass=computer)(objectClass=contact)"
                        "(objectClass=foreignSecurityPrincipal)"
                        "(objectClass=msDS-groupManagedServiceAccount))")

    def _fetch_attributes(
        self, dn_list: Sequence[str], say: Callable[[str], None]
    ) -> Dict[str, Dict[str, Any]]:
        """
        Résout les attributs des membres.

        On indexe l'annuaire en une passe paginée puis on recolle par DN en
        mémoire. On évite volontairement le filtre (distinguishedName=...) :
        selon les serveurs il est refusé, ignoré (toutes les entrées sont alors
        renvoyées) ou interprété comme une recherche approximative — trois
        façons d'obtenir des attributs faux. Les objets absents de l'index sont
        relus un par un en portée BASE, ce qui est toujours exact.
        """
        attrs = USER_ATTRS + ["objectClass"]
        by_dn: Dict[str, Dict[str, Any]] = {}
        wanted = {dn.lower() for dn in dn_list}

        say("Indexation de l'annuaire…")
        entries: List[Any] = []
        for flt in (self.DIRECTORY_FILTER, "(objectClass=*)"):
            try:
                entries = self._search(self.effective_base_dn(), flt, attrs,
                                       limit=self.scan_cap)
                break
            except ADError as exc:
                say("Indexation refusée (%s), nouvel essai…" % exc)
        if not entries:
            say("Indexation impossible : lecture objet par objet.")
        for entry in entries:
            data = self._entry_dict(entry)
            dn = attr_str(data, "distinguishedName")
            if dn:
                by_dn[dn.lower()] = data

        if len(entries) >= self.scan_cap:
            say("Index tronqué à %d objets : les objets manquants sont relus un par un."
                % self.scan_cap)

        missing = [dn for dn in dn_list if dn.lower() not in by_dn]
        for index, dn in enumerate(missing, start=1):
            say("Relecture ciblée %d/%d…" % (index, len(missing)))
            try:
                found = self._search(dn, "(objectClass=*)", attrs, scope="BASE")
            except ADError:
                found = []
            if found:
                by_dn[dn.lower()] = self._entry_dict(found[0])
        return by_dn

    def _to_member(self, data: Dict[str, Any], depth: int, via: str, chain: List[str]) -> Member:
        classes = attr_list(data, "objectClass")
        uac = 0
        try:
            uac = int(attr_str(data, "userAccountControl") or 0)
        except ValueError:
            uac = 0
        kind = classify_object(classes)
        last_logon = attr_str(data, "lastLogonTimestamp") or attr_str(data, "lastLogon")
        dn = attr_str(data, "distinguishedName")
        sid = decode_sid(raw_bytes(data, "objectSid")) or decode_sid(attr_str(data, "objectSid"))
        if not sid and kind == "Principal externe":
            sid = sid_from_dn(dn)
        return Member(
            distinguishedname=dn,
            samaccountname=attr_str(data, "sAMAccountName"),
            displayname=attr_str(data, "displayName") or attr_str(data, "name") or attr_str(data, "cn"),
            name=attr_str(data, "name") or attr_str(data, "cn"),
            userprincipalname=attr_str(data, "userPrincipalName"),
            mail=attr_str(data, "mail"),
            title=attr_str(data, "title"),
            department=attr_str(data, "department"),
            company=attr_str(data, "company"),
            manager=dn_value(attr_str(data, "manager"), "cn"),
            telephone=attr_str(data, "telephoneNumber"),
            etat=decode_account_state(uac, attr_str(data, "pwdLastSet")) if kind == "Utilisateur" else kind,
            type=kind,
            appartenance="Direct" if depth == 0 else "Via %s" % via,
            groupes_imbriques=" > ".join(chain),
            derniere_connexion=fmt_ad_datetime(last_logon),
            creation=fmt_ad_datetime(attr_str(data, "whenCreated")),
            uac=uac,
            sid=sid,
            raw={k: (v[0] if isinstance(v, list) and len(v) == 1 else v) for k, v in data.items()},
        )

    # -- filtrage ---------------------------------------------------------- #

    @staticmethod
    def filter_members(members: Iterable[Member], scope: str = "all") -> List[Member]:
        """scope: all | enabled | disabled | users"""
        scope = (scope or "all").lower()
        out = []
        for m in members:
            if scope == "users" and m.type != "Utilisateur":
                continue
            if scope == "enabled" and not (m.type == "Utilisateur" and m.etat.startswith("Actif")):
                continue
            if scope == "disabled" and not (m.type == "Utilisateur" and m.etat == "Désactivé"):
                continue
            out.append(m)
        return out


# --------------------------------------------------------------------------- #
# Export
# --------------------------------------------------------------------------- #


def write_csv(
    path: str,
    members: Sequence[Member],
    columns: Optional[Sequence[str]] = None,
    headers: Optional[Sequence[str]] = None,
    delimiter: str = ";",
    encoding: str = "utf-8-sig",
) -> int:
    """Écrit le CSV (utf-8-sig = BOM, ouvrable directement dans Excel FR)."""
    cols = list(columns or [k for k, _ in EXPORT_COLUMNS])
    titles = list(headers) if headers else [
        dict(EXPORT_COLUMNS).get(c, c) for c in cols
    ]
    with open(path, "w", newline="", encoding=encoding) as fh:
        writer = csv.writer(fh, delimiter=delimiter)
        writer.writerow(titles)
        for member in members:
            writer.writerow(member.row(cols))
    return len(members)


def members_to_dicts(members: Sequence[Member]) -> List[Dict[str, Any]]:
    return [{k: v for k, v in asdict(m).items() if k != "raw"} for m in members]

# ----------------------------------------------------------------------------
# Interface graphique et ligne de commande
# ----------------------------------------------------------------------------

#!/usr/bin/env python3
"""
Exportateur de membres de groupe Active Directory
=================================================

Interface graphique (Tkinter) pour lister puis exporter en CSV les membres
d'un groupe AD, avec ou sans dépliage des groupes imbriqués.

Lancement :
    python app.py                      -> interface graphique
    python app.py --cli --server dc1.corp.local --group "GRP_Compta" --out out.csv
    python app.py --selftest           -> auto-test hors connexion (moteur + UI)
"""


import argparse
import os
import queue
import sys
import threading
import traceback


APP_TITLE = "Exportateur de groupes Active Directory - TOUILLET Ludovic - HNCS-Groupe"

# Version affichée dans la barre d'état : permet de vérifier d'un coup d'œil
# que l'exécutable tournant correspond bien au dernier fichier livré.
APP_VERSION = "2026-09-28"

# Icône de la fenêtre, intégrée au script (aucun fichier externe nécessaire).
APP_ICON_PNG_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAABr0lEQVR4nO2bUXLDIAxEaaYHaO7WHKI9UHOI9m7NDdovMgkGW8CKtZHeZwbU1SJTwdghOLZ5aZn09v71hxaC4PbzWZ2PeMJeky4hNeMkGXS05EOQa1516YiJ51irhmIFzJJ8COu5ZA2YKflIKSfRHjAzCwNmXP1ILrfT1oDZSHP0R4AtgM3dAAvlH3nM1SuALYCNeQNe0QF/vz8Wv50v193ES7kfEno3wZzQlBrh6Hgp8YAEeQQkYpnj1ug2oFbE1nh0vC3Mb4JdBrS6X5qHjifBK4AtgI0bwBbApsuA1kakNA8dT4JXAFsAG/N9QNNhCNGDR86XKzyehObDEFLsHuL5HlAzGL1aWtTo9ApgC2BTdSeIuIvTvuqqZWgFjLzqkjLMgNFXXVKGGMDo8KSY3wTVDehdRe0q8ApgC2DjBrAFsFE3oLer0+4KvQJG/BHGba8U8xXw9Ba1xptiiEYGXQmPb4+rVgCqi9PsBtUMYF92SnkyoOWbmxxaYhFx0xwXFdBrgvbhpSd+Ljfz/wWyBqAehT1Rysn8R1OilT6qEZJKFu0BR3wkpJrNfzrrWOcfmAy3rDVxwlkAAAAASUVORK5CYII="
)
SETTINGS_FILE = settings_path()

MODES = [("LDAPS (636, recommandé)", "ldaps"), ("LDAP + StartTLS (389)", "starttls"), ("LDAP clair (389)", "ldap")]
AUTHS = [("Session Windows en cours", "sso"), ("Compte NTLM (DOMAINE\\utilisateur)", "ntlm"),
         ("Bind simple (DN ou UPN)", "simple")]
SCOPES = [
    ("Tous les membres", "all"),
    ("Utilisateurs actifs uniquement", "enabled"),
    ("Utilisateurs désactivés", "disabled"),
    ("Comptes utilisateurs seulement (actifs + désactivés)", "users"),
]
CSV_DELIMITERS = [("Point-virgule  ;  (Excel FR)", ";"), ("Virgule  ,", ","), ("Tabulation", "\t")]
CSV_ENCODINGS = [("UTF-8 avec BOM (Excel)", "utf-8-sig"), ("UTF-8", "utf-8"), ("Windows-1252", "cp1252")]


# --------------------------------------------------------------------------- #
# Ligne de commande (sans interface graphique)
# --------------------------------------------------------------------------- #


def run_cli(args: argparse.Namespace) -> int:
    if not LDAP3_AVAILABLE:
        print("ERREUR : la bibliothèque 'ldap3' est absente. Installez-la : pip install ldap3", file=sys.stderr)
        return 2

    host = resolve_host(args.server, args.domain or guess_local_domain())
    auth = "ntlm" if args.user and args.password else (args.auth or "sso")
    print("Connexion à %s:%s (%s)…" % (host, args.port or default_port(args.mode), args.mode))

    client = AdClient(
        host=host,
        port=args.port,
        mode=args.mode,
        verify_cert=not args.insecure,
        username=args.user,
        password=args.password,
        auth=auth,
        base_dn=args.base_dn,
        domain=args.domain,
    )
    try:
        client.connect()
        print("Connecté. Base : %s" % client.effective_base_dn())
        info, members = client.list_members(args.group, recursive=args.recursive,
                                            progress=lambda m: print("  " + m))
    except ADError as exc:
        print("ERREUR : %s" % exc, file=sys.stderr)
        return 1
    finally:
        client.close()

    members = AdClient.filter_members(members, args.scope)
    out = args.out or "membres_%s.csv" % "".join(
        c if c.isalnum() or c in "-_" else "_" for c in args.group)
    count = write_csv(out, members, delimiter=args.delimiter or ";")
    print("\nGroupe        : %s (%s)" % (info.name, info.group_type or "type inconnu"))
    print("Membres       : %d" % count)
    print("Fichier créé  : %s" % os.path.abspath(out))
    return 0


# --------------------------------------------------------------------------- #
# Interface graphique
# --------------------------------------------------------------------------- #


class App:
    def __init__(self, root) -> None:
        import tkinter as tk
        from tkinter import ttk

        self.tk = tk
        self.ttk = ttk
        self.root = root
        self.settings = AdSettings.load(SETTINGS_FILE)
        self.client: AdClient | None = None
        self.members: list[Member] = []
        self.group_label = ""
        self.msg_queue: "queue.Queue[tuple]" = queue.Queue()
        self.busy = False
        self._column_vars: dict[str, "tk.BooleanVar"] = {}

        root.title(APP_TITLE)
        root.geometry("1180x740")
        root.minsize(920, 560)
        self._set_icon(root, tk)

        self._build_style()
        self._build_ui()
        self._bind_shortcuts()
        self._apply_settings_to_ui()
        self.root.after(120, self._poll_queue)

    # -- construction ------------------------------------------------------ #

    @staticmethod
    def _set_icon(root, tk) -> None:
        """Pose l'icône de la fenêtre ; silencieux si le format n'est pas géré."""
        import base64

        try:
            icon = tk.PhotoImage(data=APP_ICON_PNG_B64)
            root.iconphoto(True, icon)
            root._app_icon = icon  # garde une référence, sinon l'image est libérée
        except Exception:
            pass

    def _build_style(self) -> None:
        ttk = self.ttk
        style = ttk.Style(self.root)
        try:
            if sys.platform == "win32":
                style.theme_use("vista")
            else:
                style.theme_use("clam")
        except Exception:
            pass
        style.configure("Treeview", rowheight=24)
        style.configure("Treeview.Heading", font=("", 9, "bold"))
        style.configure("Status.TLabel", padding=(6, 4))

    def _build_ui(self) -> None:
        tk, ttk = self.tk, self.ttk
        pad = {"padx": 6, "pady": 4}

        # ---------- connexion ----------
        frm_conn = ttk.LabelFrame(self.root, text=" 1. Connexion à l'Active Directory ")
        frm_conn.pack(fill="x", padx=10, pady=(10, 4))

        row1 = ttk.Frame(frm_conn); row1.pack(fill="x", **pad)
        ttk.Label(row1, text="Contrôleur de domaine :").pack(side="left")
        self.var_server = tk.StringVar()
        self.ent_server = ttk.Entry(row1, textvariable=self.var_server, width=30)
        self.ent_server.pack(side="left", padx=(4, 12))
        ttk.Label(row1, text="Port :").pack(side="left")
        self.var_port = tk.StringVar()
        self.ent_port = ttk.Entry(row1, textvariable=self.var_port, width=6)
        self.ent_port.pack(side="left", padx=(4, 12))
        ttk.Label(row1, text="Protocole :").pack(side="left")
        self.var_mode = tk.StringVar(value="ldaps")
        self.cmb_mode = ttk.Combobox(row1, textvariable=self.var_mode, width=24, state="readonly",
                                     values=[label for label, _ in MODES])
        self.cmb_mode.current(0)
        self.cmb_mode.pack(side="left", padx=(4, 12))
        self.cmb_mode.bind("<<ComboboxSelected>>", self._on_mode_change)
        self.var_verify = tk.BooleanVar(value=True)
        ttk.Checkbutton(row1, text="Vérifier le certificat", variable=self.var_verify).pack(side="left")

        row2 = ttk.Frame(frm_conn); row2.pack(fill="x", **pad)
        ttk.Label(row2, text="Base de recherche (DN) :").pack(side="left")
        self.var_base = tk.StringVar()
        ttk.Entry(row2, textvariable=self.var_base, width=44).pack(side="left", padx=(4, 4))
        ttk.Button(row2, text="Déduire", command=self.on_guess_base).pack(side="left", padx=(0, 12))
        ttk.Label(row2, text="Domaine DNS :").pack(side="left")
        self.var_domain = tk.StringVar()
        ttk.Entry(row2, textvariable=self.var_domain, width=24).pack(side="left", padx=(4, 12))
        ttk.Label(row2, text="(laisser vide = détection automatique)", foreground="#666").pack(side="left")

        row3 = ttk.Frame(frm_conn); row3.pack(fill="x", **pad)
        ttk.Label(row3, text="Authentification :").pack(side="left")
        self.var_auth = tk.StringVar(value="sso")
        self.cmb_auth = ttk.Combobox(row3, textvariable=self.var_auth, width=34, state="readonly",
                                     values=[label for label, _ in AUTHS])
        self.cmb_auth.current(0)
        self.cmb_auth.pack(side="left", padx=(4, 12))
        self.cmb_auth.bind("<<ComboboxSelected>>", self._on_auth_change)
        ttk.Label(row3, text="Compte :").pack(side="left")
        self.var_user = tk.StringVar()
        self.ent_user = ttk.Entry(row3, textvariable=self.var_user, width=26)
        self.ent_user.pack(side="left", padx=(4, 12))
        ttk.Label(row3, text="Mot de passe :").pack(side="left")
        self.var_pwd = tk.StringVar()
        self.ent_pwd = ttk.Entry(row3, textvariable=self.var_pwd, width=20, show="•")
        self.ent_pwd.pack(side="left", padx=(4, 12))

        row4 = ttk.Frame(frm_conn); row4.pack(fill="x", **pad)
        self.btn_connect = ttk.Button(row4, text="Se connecter", command=self.on_connect)
        self.btn_connect.pack(side="left")
        ttk.Button(row4, text="Se déconnecter", command=self.on_disconnect).pack(side="left", padx=6)
        self.lbl_conn = ttk.Label(row4, text="● Non connecté", foreground="#b00020")
        self.lbl_conn.pack(side="left", padx=12)
        ttk.Label(row4, text="Le mot de passe n'est jamais enregistré sur le disque.",
                  foreground="#666").pack(side="right")

        # ---------- recherche ----------
        frm_search = ttk.LabelFrame(self.root, text=" 2. Groupe ")
        frm_search.pack(fill="x", padx=10, pady=4)

        s1 = ttk.Frame(frm_search); s1.pack(fill="x", **pad)
        ttk.Label(s1, text="Nom du groupe :").pack(side="left")
        self.var_pattern = tk.StringVar()
        self.ent_pattern = ttk.Entry(s1, textvariable=self.var_pattern, width=38)
        self.ent_pattern.pack(side="left", padx=(4, 8))
        ttk.Button(s1, text="Rechercher le groupe", command=self.on_search_group).pack(side="left")
        ttk.Label(s1, text="  Résultats :").pack(side="left")
        self.var_group = tk.StringVar()
        self.cmb_group = ttk.Combobox(s1, textvariable=self.var_group, width=44, values=[])
        self.cmb_group.pack(side="left", padx=(4, 8), fill="x", expand=True)
        ttk.Label(s1, text="(joker * accepté)", foreground="#666").pack(side="left")

        s2 = ttk.Frame(frm_search); s2.pack(fill="x", **pad)
        self.var_recursive = tk.BooleanVar(value=False)
        ttk.Checkbutton(s2, text="Inclure les groupes imbriqués (récursif)",
                        variable=self.var_recursive).pack(side="left")
        ttk.Label(s2, text="     Afficher :").pack(side="left")
        self.var_scope = tk.StringVar(value="all")
        self.cmb_scope = ttk.Combobox(s2, textvariable=self.var_scope, width=42, state="readonly",
                                      values=[label for label, _ in SCOPES])
        self.cmb_scope.current(0)
        self.cmb_scope.pack(side="left", padx=4)
        self.cmb_scope.bind("<<ComboboxSelected>>", lambda _e: self._fill_tree())
        self.btn_members = ttk.Button(s2, text="Lister les membres  (F5)", command=self.on_list_members)
        self.btn_members.pack(side="left", padx=12)

        # ---------- résultats ----------
        frm_res = ttk.LabelFrame(self.root, text=" 3. Résultats ")
        frm_res.pack(fill="both", expand=True, padx=10, pady=4)

        bar = ttk.Frame(frm_res); bar.pack(fill="x", **pad)
        ttk.Button(bar, text="Exporter en CSV…", command=self.on_export).pack(side="left")
        ttk.Button(bar, text="Copier dans le presse-papiers", command=self.on_copy).pack(side="left", padx=6)
        ttk.Label(bar, text="     Séparateur :").pack(side="left")
        self.var_delim = tk.StringVar(value=CSV_DELIMITERS[0][0])
        ttk.Combobox(bar, textvariable=self.var_delim, width=22, state="readonly",
                     values=[l for l, _ in CSV_DELIMITERS]).pack(side="left", padx=4)
        ttk.Label(bar, text="Encodage :").pack(side="left", padx=(8, 2))
        self.var_enc = tk.StringVar(value=CSV_ENCODINGS[0][0])
        ttk.Combobox(bar, textvariable=self.var_enc, width=20, state="readonly",
                     values=[l for l, _ in CSV_ENCODINGS]).pack(side="left")
        ttk.Button(bar, text="Colonnes…", command=self.on_choose_columns).pack(side="left", padx=10)
        self.lbl_count = ttk.Label(bar, text="Aucun membre chargé", font=("", 9, "bold"))
        self.lbl_count.pack(side="right")

        # Un conteneur dédié : grid pour le tableau, pack pour le reste
        # (Tkinter interdit de mélanger les deux gestionnaires sur un même parent).
        frm_table = ttk.Frame(frm_res)
        frm_table.pack(fill="both", expand=True, padx=6, pady=(0, 6))

        cols = [k for k, _ in EXPORT_COLUMNS]
        self.tree = ttk.Treeview(frm_table, columns=cols, show="headings", selectmode="extended")
        for key, title in EXPORT_COLUMNS:
            self.tree.heading(key, text=title, command=lambda k=key: self._sort_by(k))
            width = {"distinguishedname": 340, "displayname": 180, "samaccountname": 140,
                     "mail": 200, "userprincipalname": 220, "groupes_imbriques": 200,
                     "title": 140, "department": 130, "manager": 130}.get(key, 100)
            self.tree.column(key, width=width, anchor="w", stretch=(key in ("displayname", "mail")))
        vsb = ttk.Scrollbar(frm_table, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(frm_table, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        frm_table.rowconfigure(0, weight=1)
        frm_table.columnconfigure(0, weight=1)
        self.tree.tag_configure("odd", background="#f4f6f9")
        self.tree.tag_configure("disabled", foreground="#a33")
        self.tree.bind("<Double-1>", self.on_show_details)
        self.tree.bind("<Button-3>", self.on_tree_menu)

        # ---------- barre d'état ----------
        bottom = ttk.Frame(self.root); bottom.pack(fill="x", padx=10, pady=(0, 8))
        self.progress = ttk.Progressbar(bottom, mode="indeterminate", length=180)
        self.progress.pack(side="left")
        self.var_status = tk.StringVar(value="Prêt. Renseignez le contrôleur de domaine puis cliquez sur « Se connecter ». (version %s)" % APP_VERSION)
        ttk.Label(bottom, textvariable=self.var_status, style="Status.TLabel").pack(side="left", padx=8)

    def _bind_shortcuts(self) -> None:
        self.root.bind("<F5>", lambda e: self.on_list_members())
        self.root.bind("<Control-e>", lambda e: self.on_export())
        self.root.bind("<Control-E>", lambda e: self.on_export())
        self.ent_pattern.bind("<Return>", lambda _e: self.on_search_group())
        self.cmb_group.bind("<Return>", lambda _e: self.on_list_members())

    # -- réglages ---------------------------------------------------------- #

    def _apply_settings_to_ui(self) -> None:
        s = self.settings
        self.var_server.set(s.server or "")
        self.var_mode.set(dict((v, l) for l, v in MODES).get(s.mode, MODES[0][0]))
        self._on_mode_change()
        if s.port:
            self.var_port.set(str(s.port))
        self.var_verify.set(bool(s.verify_cert))
        self.var_base.set(s.base_dn or "")
        self.var_domain.set(s.domain or guess_local_domain())
        self.var_auth.set(dict((v, l) for l, v in AUTHS).get(s.auth, AUTHS[0][0]))
        self.var_user.set(s.username or "")
        self._on_auth_change()

    def _collect_settings(self) -> AdSettings:
        return AdSettings(
            server=self.var_server.get().strip(),
            port=self.var_port.get().strip(),
            mode=self._mode_value(),
            verify_cert=bool(self.var_verify.get()),
            base_dn=self.var_base.get().strip(),
            domain=self.var_domain.get().strip(),
            auth=self._auth_value(),
            username=self.var_user.get().strip() if self._auth_value() != "sso" else "",
            remember_user=True,
        )

    def _mode_value(self) -> str:
        return dict(MODES).get(self.var_mode.get(), "ldaps")

    def _auth_value(self) -> str:
        return dict(AUTHS).get(self.var_auth.get(), "sso")

    def _on_mode_change(self, *_args) -> None:
        mode = self._mode_value()
        if not self.var_port.get().strip() or self.var_port.get().strip() in ("389", "636"):
            self.var_port.set(str(default_port(mode)))

    def _on_auth_change(self, *_args) -> None:
        need = self._auth_value() != "sso"
        state = "normal" if need else "disabled"
        for widget in (self.ent_user, self.ent_pwd):
            try:
                widget.configure(state=state)
            except Exception:
                pass

    # -- tâches de fond ---------------------------------------------------- #

    def _start_task(self, label: str, worker, on_done) -> None:
        if self.busy:
            self._status("Une opération est déjà en cours…")
            return
        if not LDAP3_AVAILABLE:
            self._error("La bibliothèque 'ldap3' est absente.\n\nInstallez-la avec :\n    pip install ldap3")
            return
        self.busy = True
        self._status(label)
        self.progress.start(12)

        def runner() -> None:
            try:
                result = worker()
                self.msg_queue.put(("ok", result, on_done))
            except ADError as exc:
                self.msg_queue.put(("ad_error", str(exc), on_done))
            except Exception:
                self.msg_queue.put(("error", traceback.format_exc(), on_done))

        threading.Thread(target=runner, daemon=True).start()

    def _poll_queue(self) -> None:
        try:
            while True:
                kind, payload, on_done = self.msg_queue.get_nowait()
                if kind == "progress":
                    self._status(str(payload))
                    continue
                self.busy = False
                self.progress.stop()
                if kind == "ok":
                    self._status("Terminé.")
                    if on_done:
                        on_done(payload)
                elif kind == "ad_error":
                    self._status("Erreur.")
                    self._error(payload)
                else:
                    self._status("Erreur inattendue.")
                    self._error("Erreur inattendue :\n\n%s" % payload)
        except queue.Empty:
            pass
        self.root.after(120, self._poll_queue)

    def _status(self, text: str) -> None:
        self.var_status.set(text)

    def _error(self, text: str) -> None:
        from tkinter import messagebox
        messagebox.showerror(APP_TITLE, text)

    def _info(self, text: str) -> None:
        from tkinter import messagebox
        messagebox.showinfo(APP_TITLE, text)

    # -- actions ----------------------------------------------------------- #

    def _client_from_ui(self) -> AdClient:
        s = self._collect_settings()
        if not s.server:
            raise ADError("Renseignez d'abord le nom du contrôleur de domaine.")
        host = resolve_host(s.server, s.domain)
        auth = s.auth
        user = s.username
        if auth == "ntlm":
            if not user or not self.var_pwd.get():
                raise ADError("Un compte (DOMAINE\\utilisateur) et un mot de passe sont requis en NTLM.")
        if auth in ("ntlm", "simple"):
            if auth == "ntlm" and "\\" not in user and "@" not in user:
                dom = s.domain.split(".")[0] if s.domain else ""
                user = "%s\\%s" % (dom, user) if dom else user
        port = int(s.port) if str(s.port).strip().isdigit() else None
        return AdClient(host=host, port=port, mode=s.mode, verify_cert=s.verify_cert,
                        username=user, password=self.var_pwd.get(), auth=auth,
                        base_dn=s.base_dn, domain=s.domain)

    def on_guess_base(self) -> None:
        s = self._collect_settings()
        base, src = guess_base_dn(host=s.server, domain=s.domain,
                                  username=s.username)
        if base:
            self.var_base.set(base)
            self._status("Base déduite : %s (%s)" % (base, src))
        else:
            self._info(
                "Impossible de déduire la base automatiquement.\n\n"
                "Sur votre poste Windows, ouvrez PowerShell et tapez :\n"
                "    ([adsi]\"LDAP://RootDSE\").defaultNamingContext\n"
                "puis recopiez le résultat (ex. DC=hncs,DC=fr) dans le champ.\n\n"
                "À défaut : votre domaine DNS « hncs-groupe.fr » devient\n"
                "« DC=hncs-groupe,DC=fr » (chaque partie précédée de DC=).")

    def on_connect(self) -> None:
        client = None
        try:
            client = self._client_from_ui()
        except ADError as exc:
            self._error(str(exc))
            return

        def worker() -> str:
            client.connect()
            return client.effective_base_dn() or "(aucune base détectée)"

        def done(base_dn: str) -> None:
            self.client = client
            self.lbl_conn.configure(text="● Connecté à %s" % client.host, foreground="#0a7a2f")
            if not self.var_base.get().strip() and base_dn:
                self.var_base.set(base_dn)
            if not self.var_domain.get().strip() and client.dns_host_name:
                self.var_domain.set(".".join(client.dns_host_name.split(".")[1:]) or client.dns_host_name)
            self._collect_settings().save(SETTINGS_FILE)
            if base_dn:
                self._status("Connecté à %s — base %s (%s)"
                             % (client.host, base_dn, client.base_dn_source()))
            else:
                self._status("Connecté à %s mais base introuvable : renseignez "
                             "« Base de recherche (DN) » (ex. DC=societe,DC=fr)."
                             % client.host)
            self.ent_pattern.focus_set()

        self._start_task("Connexion à %s…" % client.host, worker, done)

    def on_disconnect(self) -> None:
        if self.client:
            self.client.close()
        self.client = None
        self.lbl_conn.configure(text="● Non connecté", foreground="#b00020")
        self._status("Déconnecté.")

    def _ensure_client(self) -> AdClient | None:
        if self.client is None:
            self._error("Connectez-vous d'abord à un contrôleur de domaine.")
            return None
        return self.client

    def on_search_group(self) -> None:
        client = self._ensure_client()
        if client is None:
            return
        pattern = self.var_pattern.get().strip() or "*"

        def worker() -> list:
            return client.find_groups(pattern)

        def done(groups: list) -> None:
            values = ["%s  —  %s" % (g.name, g.dn) for g in groups]
            self.cmb_group.configure(values=values)
            if not groups:
                self._info(
                    "Aucun groupe ne correspond à « %s ».\n\n"
                    "Pistes :\n"
                    "  • le nom est comparé au nom complet, au nom « pre-Windows 2000 »\n"
                    "    (sAMAccountName) et au CN — essayez un morceau avec des * ;\n"
                    "  • vérifiez l'orthographe et les accents ;\n"
                    "  • le groupe est peut-être dans une autre OU hors de la base\n"
                    "    de recherche, dans un autre domaine de la forêt, ou non\n"
                    "    lisible par votre compte." % pattern)
                self._status("Aucun groupe trouvé.")
                return
            self.cmb_group.current(0)
            self._status("%d groupe(s) trouvé(s)." % len(groups))

        self._start_task("Recherche des groupes…", worker, done)

    def on_list_members(self) -> None:
        client = self._ensure_client()
        if client is None:
            return
        target = self.var_group.get().strip()
        if not target:
            target = self.var_pattern.get().strip()
        if not target:
            self._error("Saisissez ou sélectionnez d'abord un groupe.")
            return
        group_name = target.split("  —  ")[0].strip()
        recursive = bool(self.var_recursive.get())

        def worker():
            def progress(msg: str) -> None:
                self.msg_queue.put(("progress", msg, None))
            return client.list_members(group_name, recursive=recursive, progress=progress)

        def done(result) -> None:
            info, members = result
            self.members = members
            self.group_label = "%s (%s)" % (info.name, info.group_type or "type inconnu")
            self._fill_tree()
            self._status("Groupe %s — %d membre(s) au total." % (self.group_label, len(members)))

        self._start_task("Lecture des membres de %s…" % group_name, worker, done)

    # -- affichage --------------------------------------------------------- #

    def _visible_columns(self) -> list[str]:
        return [k for k, _ in EXPORT_COLUMNS if self._column_vars.get(k, None) is None or self._column_vars[k].get()]

    def _fill_tree(self) -> None:
        scope = dict(SCOPES).get(self.var_scope.get(), "all")
        rows = AdClient.filter_members(self.members, scope)
        self.tree.delete(*self.tree.get_children())
        for index, member in enumerate(rows):
            values = member.row([k for k, _ in EXPORT_COLUMNS])
            tags = ["odd"] if index % 2 else []
            if member.etat == "Désactivé":
                tags.append("disabled")
            self.tree.insert("", "end", values=values, tags=tags)
        total = len(self.members)
        users = sum(1 for m in self.members if m.type == "Utilisateur")
        disabled = sum(1 for m in self.members if m.etat == "Désactivé")
        self.lbl_count.configure(
            text="%d ligne(s) affichée(s) / %d membre(s) — %d utilisateur(s), %d désactivé(s)"
                 % (len(rows), total, users, disabled))

    def _sort_by(self, column: str) -> None:
        items = [(self.tree.set(i, column), i) for i in self.tree.get_children("")]
        reverse = getattr(self, "_sort_reverse", {}).get(column, False)
        items.sort(key=lambda t: t[0].lower(), reverse=reverse)
        for pos, (_, iid) in enumerate(items):
            self.tree.move(iid, "", pos)
        self._sort_reverse = getattr(self, "_sort_reverse", {})
        self._sort_reverse[column] = not reverse

    def _selected_rows(self) -> list[Member]:
        scope = dict(SCOPES).get(self.var_scope.get(), "all")
        rows = AdClient.filter_members(self.members, scope)
        index_map = {iid: pos for pos, iid in enumerate(self.tree.get_children(""))}
        return [rows[index_map[iid]] for iid in self.tree.selection() if iid in index_map]

    def on_show_details(self, *_args) -> None:
        selected = self._selected_rows()
        if not selected:
            return
        self._show_details(selected[0])

    def _show_details(self, member: Member) -> None:
        tk, ttk = self.tk, self.ttk
        win = tk.Toplevel(self.root)
        win.title("Détails — %s" % (member.samaccountname or member.displayname or member.distinguishedname))
        win.geometry("620x520")
        txt = tk.Text(win, wrap="word", padx=10, pady=10)
        txt.pack(fill="both", expand=True)
        lines = ["%s : %s" % (title, getattr(member, key, "") or "") for key, title in EXPORT_COLUMNS]
        lines.append("SID : %s" % member.sid)
        lines.append("userAccountControl : %s" % member.uac)
        lines.append("")
        lines.append("— Attributs bruts —")
        for key in sorted(member.raw or {}):
            value = member.raw[key]
            if isinstance(value, bytes):
                value = "<%d octets>" % len(value)
            lines.append("%s : %s" % (key, value))
        txt.insert("1.0", "\n".join(lines))
        txt.configure(state="disabled")
        ttk.Button(win, text="Fermer", command=win.destroy).pack(pady=6)

    def on_tree_menu(self, event) -> None:
        iid = self.tree.identify_row(event.y)
        if not iid:
            return
        self.tree.selection_set(iid)
        menu = self.tk.Menu(self.root, tearoff=0)
        menu.add_command(label="Voir les détails", command=self.on_show_details)
        menu.add_command(label="Copier la ligne", command=self.on_copy)
        menu.tk_popup(event.x_root, event.y_root)

    def on_choose_columns(self) -> None:
        tk, ttk = self.tk, self.ttk
        win = tk.Toplevel(self.root)
        win.title("Colonnes affichées / exportées")
        win.geometry("380x560")
        frame = ttk.Frame(win); frame.pack(fill="both", expand=True, padx=10, pady=10)
        self._column_vars = {}
        for key, title in EXPORT_COLUMNS:
            var = tk.BooleanVar(value=True)
            self._column_vars[key] = var
            ttk.Checkbutton(frame, text=title, variable=var).pack(anchor="w", pady=1)
        bottom = ttk.Frame(win); bottom.pack(fill="x", pady=8)

        def apply() -> None:
            visible = self._visible_columns()
            for key, _ in EXPORT_COLUMNS:
                self.tree.column(key, stretch=False)
                try:
                    self.tree.heading(key, text=dict(EXPORT_COLUMNS)[key])
                except Exception:
                    pass
            self.tree.configure(displaycolumns=visible)
            win.destroy()
            self._fill_tree()

        ttk.Button(bottom, text="Tout", command=lambda: [v.set(True) for v in self._column_vars.values()]).pack(side="left", padx=4)
        ttk.Button(bottom, text="Rien", command=lambda: [v.set(False) for v in self._column_vars.values()]).pack(side="left", padx=4)
        ttk.Button(bottom, text="Appliquer", command=apply).pack(side="right", padx=4)

    # -- export ------------------------------------------------------------ #

    def _rows_to_export(self) -> tuple[list[Member], list[str], list[str]]:
        scope = dict(SCOPES).get(self.var_scope.get(), "all")
        selected = self._selected_rows()
        rows = selected if selected else AdClient.filter_members(self.members, scope)
        cols = self._visible_columns()
        titles = [dict(EXPORT_COLUMNS)[c] for c in cols]
        return rows, cols, titles

    def on_copy(self) -> None:
        rows, _cols, titles = self._rows_to_export()
        if not rows:
            self._info("Aucune ligne à copier.")
            return
        delim = dict(CSV_DELIMITERS).get(self.var_delim.get(), ";")
        lines = [delim.join(titles)]
        lines.extend(delim.join(member.row(_cols)) for member in rows)
        self.root.clipboard_clear()
        self.root.clipboard_append("\r\n".join(lines))
        self._status("%d ligne(s) copiée(s) dans le presse-papiers." % len(rows))

    def on_export(self) -> None:
        rows, cols, titles = self._rows_to_export()
        if not rows:
            self._info("Aucune ligne à exporter.\n\nListez d'abord les membres d'un groupe.")
            return
        from tkinter import filedialog
        default = "membres_%s.csv" % "".join(
            c if c.isalnum() or c in "-_" else "_" for c in (self.group_label.split(" (")[0] or "groupe"))
        path = filedialog.asksaveasfilename(
            title="Exporter les membres en CSV",
            defaultextension=".csv",
            initialfile=default,
            filetypes=[("Fichier CSV", "*.csv"), ("Tous les fichiers", "*.*")],
        )
        if not path:
            return
        delim = dict(CSV_DELIMITERS).get(self.var_delim.get(), ";")
        encoding = dict(CSV_ENCODINGS).get(self.var_enc.get(), "utf-8-sig")
        try:
            count = write_csv(path, rows, columns=cols, headers=titles,
                              delimiter=delim, encoding=encoding)
        except OSError as exc:
            self._error("Écriture impossible : %s" % exc)
            return
        self._status("%d ligne(s) exportée(s) vers %s" % (count, path))
        self._info("%d ligne(s) exportée(s) vers :\n%s" % (count, path))


def launch_gui() -> int:
    try:
        import tkinter as tk
    except ImportError:
        print("Tkinter est indisponible sur cet interpréteur Python.", file=sys.stderr)
        return 2
    if not LDAP3_AVAILABLE:
        print("ATTENTION : 'ldap3' est absent — installez-le avec : pip install ldap3", file=sys.stderr)
    root = tk.Tk()
    App(root)
    root.mainloop()
    return 0


def selftest() -> int:
    """Vérification hors ligne : logique pure + instanciation de l'interface."""
    import unittest

    tests_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tests")
    ok = True
    if os.path.isdir(tests_dir):
        loader = unittest.TestLoader()
        suite = loader.discover(tests_dir)
        result = unittest.TextTestRunner(verbosity=2).run(suite)
        ok = result.wasSuccessful()

        # Sonde de diagnostic (utile dans un exe PyInstaller) : vérifie que les
        # modules de test voient bien le même objet module moteur que l'app.
        try:
            import test_fake_ad
            engine = (sys.modules.get("ad_core") or sys.modules.get("ad_group_exporter")
                      or sys.modules.get("__main__"))
            print("SONDE fichier moteur : %s" % getattr(engine, "__file__", "?"))
            print("SONDE identité ADError : %s" % (test_fake_ad.ADError is engine.ADError))
        except Exception as exc:  # pragma: no cover
            print("SONDE en erreur : %s" % exc)
    else:
        print("Dossier tests/ absent : suite unitaire ignorée (build fichier unique).")

    if os.environ.get("DISPLAY"):
        try:
            import tkinter as tk
            root = tk.Tk()
            root.withdraw()
            app = App(root)
            app.root.update_idletasks()
            app.root.update()

            def _walk(w):
                yield w
                for c in w.winfo_children():
                    yield from _walk(c)
            btn_texts = [str(c.cget("text")) for c in _walk(app.root)
                         if c.winfo_class() == "TButton"]
            if "Déduire" not in btn_texts:
                raise RuntimeError("bouton « Déduire » introuvable dans l'interface")

            # Le bouton doit réellement fonctionner : on l'« appuie ».
            app.var_domain.set("corp.exemple.fr")
            app.var_base.set("")
            app.on_guess_base()
            if app.var_base.get() != "DC=corp,DC=exemple,DC=fr":
                raise RuntimeError("on_guess_base ne remplit pas la base : %r"
                                   % app.var_base.get())
            if guess_base_dn()[0] == "":
                captured = []
                app._info = captured.append
                app.var_domain.set("")
                app.var_server.set("")
                app.var_base.set("")
                app.on_guess_base()
                if not any("PowerShell" in m for m in captured):
                    raise RuntimeError("on_guess_base n'affiche pas l'aide attendue")
            root.destroy()
            print("Interface graphique : OK (fenêtre créée, bouton « Déduire » présent)")
        except Exception as exc:
            print("Interface graphique : ÉCHEC -> %s" % exc)
            ok = False
    else:
        print("Interface graphique : non testée (aucun affichage DISPLAY disponible)")
    return 0 if ok else 1


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=APP_TITLE)
    parser.add_argument("--cli", action="store_true", help="mode ligne de commande (sans interface)")
    parser.add_argument("--selftest", action="store_true", help="exécute l'auto-test puis quitte")
    parser.add_argument("--server", help="contrôleur de domaine (nom ou IP)")
    parser.add_argument("--port", type=int)
    parser.add_argument("--mode", default="ldaps", choices=["ldap", "ldaps", "starttls"])
    parser.add_argument("--insecure", action="store_true", help="ne pas vérifier le certificat LDAPS")
    parser.add_argument("--base-dn", dest="base_dn", default="")
    parser.add_argument("--domain", default="")
    parser.add_argument("--user", default="")
    parser.add_argument("--password", default="")
    parser.add_argument("--auth", choices=["sso", "ntlm", "simple"])
    parser.add_argument("--group", help="groupe à exporter (mode --cli)")
    parser.add_argument("--recursive", action="store_true", help="déplier les groupes imbriqués")
    parser.add_argument("--scope", default="all", choices=["all", "enabled", "disabled", "users"])
    parser.add_argument("--out", help="fichier CSV de sortie")
    parser.add_argument("--delimiter", default=";")
    args = parser.parse_args(argv)

    if args.selftest:
        return selftest()
    if args.cli:
        if not args.server or not args.group:
            parser.error("--cli nécessite --server et --group")
        return run_cli(args)
    return launch_gui()


if __name__ == "__main__":
    sys.exit(main())
